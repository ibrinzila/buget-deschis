/* Design System page */
function SystemPage() {
  return (
    <div style={{background:'var(--paper)'}}>
      <section style={{borderBottom:'1px solid var(--ink)', padding:'56px 0'}}>
        <div className="wrap">
          <div className="mono" style={{fontSize:'11px', color:'var(--ink-3)', marginBottom:'12px'}}>PLATFORMĂ / §05 · DESIGN SYSTEM</div>
          <h1 className="serif" style={{fontSize:'var(--fs-d2)', lineHeight:0.95, fontWeight:400, letterSpacing:'-0.03em', margin:'0 0 16px', maxWidth:'900px'}}>
            Un sistem <em style={{color:'var(--forest)'}}>civic-editorial</em> pentru date publice.
          </h1>
          <p style={{fontSize:'17px', lineHeight:1.55, color:'var(--ink-2)', margin:0, maxWidth:'720px'}}>
            Hârtie + cerneală + pădure + ocru. Gândit pentru citire atentă, cu aer de ziar serios. Tipar serif + sans umanist + mono pentru cifre.
          </p>
        </div>
      </section>

      {/* Principles */}
      <section style={{padding:'48px 0', borderBottom:'1px solid var(--ink)'}}>
        <div className="wrap">
          <Eyebrow num="§A">Principii</Eyebrow>
          <div style={{display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:0, border:'1px solid var(--ink)'}}>
            {[
              ['01','Demnitatea datelor','Tratăm cifrele ca editorial de calitate — aer, tipografie, adnotări. Nu dashboard.'],
              ['02','Încredere prin textură','Paletă de hârtie, zero gradient pufos. Muchii drepte, borduri vizibile.'],
              ['03','Bucurie în acțiune','Calculul personal, turul ghidat, chitanța descărcabilă — date care fac ceva.'],
              ['04','Accesibil by default','Contrast ≥ 4.5. Focus vizibil. Tastatura e cetățean de rangul întâi.'],
            ].map(([n,t,d]) => (
              <div key={n} style={{padding:'28px 24px', borderRight: n!=='04'?'1px solid var(--ink)':'none', minHeight:'220px', display:'flex', flexDirection:'column'}}>
                <div className="mono" style={{fontSize:'10px', color:'var(--ink-3)', marginBottom:'24px'}}>— {n}</div>
                <h3 className="serif" style={{fontSize:'22px', fontWeight:500, margin:'0 0 12px', letterSpacing:'-0.01em'}}>{t}</h3>
                <p style={{fontSize:'13px', lineHeight:1.55, color:'var(--ink-2)', margin:0}}>{d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Colors */}
      <section style={{padding:'48px 0', borderBottom:'1px solid var(--ink)'}}>
        <div className="wrap">
          <Eyebrow num="§B">Paletă</Eyebrow>
          <h2 className="serif" style={{fontSize:'var(--fs-h1)', fontWeight:500, margin:'0 0 32px', letterSpacing:'-0.02em'}}>Culori · token, rol, utilizare</h2>

          <div style={{marginBottom:'32px'}}>
            <div className="eyebrow" style={{marginBottom:'12px'}}>Hârtie & cerneală — fundal/text</div>
            <div style={{display:'grid', gridTemplateColumns:'repeat(6,1fr)', gap:'12px'}}>
              {[
                ['--paper','#F4F1EA','Fundal primar'],
                ['--paper-2','#EAE5D8','Secțiuni alternate'],
                ['--paper-3','#DCD5C2','Card passive'],
                ['--ink','#131310','Text primar'],
                ['--ink-2','#3A3A33','Text secundar'],
                ['--ink-3','#6B6B61','Eyebrow/meta'],
              ].map(([v,h,u]) => <Swatch key={v} v={v} h={h} u={u}/>)}
            </div>
          </div>

          <div style={{marginBottom:'32px'}}>
            <div className="eyebrow" style={{marginBottom:'12px'}}>Brand — pădure (primar) & ocru (accent)</div>
            <div style={{display:'grid', gridTemplateColumns:'repeat(6,1fr)', gap:'12px'}}>
              {[
                ['--forest','#2F4A3A','Primar · CTA, accent'],
                ['--forest-2','#1E3225','Hover pădure'],
                ['--forest-3','#4A6A56','Forest deschis'],
                ['--ochre','#C08A2E','Accent secundar'],
                ['--ochre-2','#9B6E1F','Ochre închis'],
                ['--ochre-3','#E8C578','Ochre pe ink'],
              ].map(([v,h,u]) => <Swatch key={v} v={v} h={h} u={u}/>)}
            </div>
          </div>

          <div>
            <div className="eyebrow" style={{marginBottom:'12px'}}>Date — categorical (sectoare COFOG)</div>
            <div style={{display:'grid', gridTemplateColumns:'repeat(6,1fr)', gap:'12px'}}>
              {[
                ['--d-social','#2F4A3A','Protecție Socială'],
                ['--d-education','#6B8E4E','Educație'],
                ['--d-health','#C08A2E','Sănătate'],
                ['--d-economy','#3F5F6E','Economic'],
                ['--d-security','#8B3A2F','Ordine Publică'],
                ['--d-culture','#B85C2E','Cultură'],
              ].map(([v,h,u]) => <Swatch key={v} v={v} h={h} u={u} dark/>)}
            </div>
          </div>
        </div>
      </section>

      {/* Typography */}
      <section style={{padding:'48px 0', borderBottom:'1px solid var(--ink)', background:'var(--paper-2)'}}>
        <div className="wrap">
          <Eyebrow num="§C">Tipografie</Eyebrow>
          <h2 className="serif" style={{fontSize:'var(--fs-h1)', fontWeight:500, margin:'0 0 32px', letterSpacing:'-0.02em'}}>Trei familii, roluri clare.</h2>
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:'24px', marginBottom:'40px'}}>
            {[
              {name:'Fraunces', role:'Display · titluri', sample:'Unde merg banii?', cls:'serif', css:'--serif'},
              {name:'Inter', role:'Body · UI', sample:'Transparența nu-i lux.', cls:'', css:'--sans'},
              {name:'JetBrains Mono', role:'Cifre · eyebrow · cod', sample:'100 000 000 000', cls:'mono', css:'--mono'},
            ].map(f => (
              <div key={f.name} style={{border:'1px solid var(--ink)', padding:'24px', background:'var(--paper)'}}>
                <div className="mono" style={{fontSize:'10px', color:'var(--ink-3)', marginBottom:'16px'}}>{f.css}</div>
                <div className={f.cls} style={{fontSize:'32px', fontWeight:500, lineHeight:1.1, margin:'0 0 20px', color:'var(--ink)', fontStyle: f.name==='Fraunces'?'italic':'normal'}}>{f.sample}</div>
                <div className="serif" style={{fontSize:'20px', fontWeight:500}}>{f.name}</div>
                <div style={{fontSize:'12px', color:'var(--ink-3)', marginTop:'4px'}}>{f.role}</div>
              </div>
            ))}
          </div>

          <div className="eyebrow" style={{marginBottom:'16px'}}>Scară tipografică</div>
          <div style={{background:'var(--paper)', border:'1px solid var(--ink)', padding:'24px', display:'flex', flexDirection:'column', gap:'16px'}}>
            {[
              ['Display 1', 'clamp(48, 7.5vw, 112px)', '7.5vw', '112px'],
              ['Display 2', '36 → 72px', '5vw', '72px'],
              ['H1', '28 → 44px', '3vw', '44px'],
              ['H2', '22 → 30px', '2vw', '30px'],
              ['Body', '16px', 'fix', '16px'],
              ['Small', '14px', 'fix', '14px'],
              ['Micro', '11px', 'fix', '11px'],
            ].map(([n,s,c,px]) => (
              <div key={n} style={{display:'grid', gridTemplateColumns:'120px 1fr 140px', gap:'16px', alignItems:'baseline', borderBottom:'1px solid var(--rule)', paddingBottom:'12px'}}>
                <div className="mono" style={{fontSize:'11px', color:'var(--ink-3)'}}>{n}</div>
                <div className="serif" style={{fontSize: px, fontWeight:500, lineHeight:1, letterSpacing:'-0.02em', color:'var(--ink)'}}>Buget</div>
                <div className="mono" style={{fontSize:'11px', color:'var(--ink-3)', textAlign:'right'}}>{s}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Components */}
      <section style={{padding:'48px 0', borderBottom:'1px solid var(--ink)'}}>
        <div className="wrap">
          <Eyebrow num="§D">Componente</Eyebrow>
          <h2 className="serif" style={{fontSize:'var(--fs-h1)', fontWeight:500, margin:'0 0 32px', letterSpacing:'-0.02em'}}>Butoane, tag-uri, cartele, tabele.</h2>

          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:'24px', marginBottom:'32px'}}>
            <Demo title="Butoane">
              <div style={{display:'flex', flexWrap:'wrap', gap:'10px'}}>
                <button className="btn btn-forest">Primar forest</button>
                <button className="btn btn-primary">Primar ink</button>
                <button className="btn btn-ochre">Accent ochre</button>
                <button className="btn">Secundar</button>
                <button className="btn btn-ghost">Ghost</button>
              </div>
            </Demo>
            <Demo title="Tag-uri & status">
              <div style={{display:'flex', flexWrap:'wrap', gap:'8px', alignItems:'center'}}>
                <span className="tag">COFOG 10</span>
                <span className="tag tag-dot">OCDS 1.1</span>
                <span className="tag tag-dot tag-live">MTender live</span>
                <span style={{fontFamily:'var(--mono)', fontSize:'10px', padding:'3px 8px', border:'1px solid var(--forest)', color:'var(--forest)'}}>ACTIV</span>
                <span style={{fontFamily:'var(--mono)', fontSize:'10px', padding:'3px 8px', border:'1px solid var(--bad)', color:'var(--bad)'}}>ANULAT</span>
              </div>
            </Demo>
          </div>

          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:'24px', marginBottom:'32px'}}>
            <Demo title="Stat editorial">
              <div className="eyebrow">Executat</div>
              <div className="serif" style={{fontSize:'44px', fontWeight:500, color:'var(--forest)', lineHeight:1, margin:'4px 0'}}>94.2 <span className="mono" style={{fontSize:'12px', color:'var(--ink-3)', fontWeight:400}}>mld</span></div>
              <div style={{fontSize:'11px', color:'var(--ink-3)'}}>93.1% din aprobat · ↑7.4%</div>
            </Demo>
            <Demo title="Blocul eyebrow + §">
              <Eyebrow num="§02">Tendință 2019–2024</Eyebrow>
              <div className="serif" style={{fontSize:'20px', fontWeight:500, letterSpacing:'-0.01em'}}>Bugetul a crescut cu <em style={{color:'var(--forest)'}}>61%</em></div>
            </Demo>
            <Demo title="Input text">
              <input placeholder="Caută…" style={{width:'100%', padding:'12px', border:'1px solid var(--ink)', background:'var(--paper)', fontFamily:'var(--sans)', fontSize:'13px'}}/>
              <div style={{marginTop:'8px', fontSize:'11px', color:'var(--ink-3)'}}>Focus: outline ochre 2px</div>
            </Demo>
          </div>

          <Demo title="Rând de tabel (hover)">
            <table style={{width:'100%', borderCollapse:'collapse'}}>
              <thead><tr style={{borderBottom:'1px solid var(--ink)', background:'var(--paper-2)'}}>
                {['COFOG','Sector','Alocat','Execuție'].map(h => <th key={h} style={{textAlign:'left', padding:'10px 14px', fontFamily:'var(--mono)', fontSize:'10px', letterSpacing:'0.1em', textTransform:'uppercase', color:'var(--ink-3)'}}>{h}</th>)}
              </tr></thead>
              <tbody>
                {[['10','Protecție Socială','28 500','95.4%'],['09','Educație','18 200','94.0%']].map((r,i) => (
                  <tr key={i} style={{borderBottom:'1px solid var(--rule)'}}>
                    <td style={{padding:'10px 14px', fontFamily:'var(--mono)', fontSize:'11px', color:'var(--ink-3)'}}>{r[0]}</td>
                    <td style={{padding:'10px 14px', fontSize:'13px', fontWeight:500}}>{r[1]}</td>
                    <td style={{padding:'10px 14px', fontFamily:'var(--mono)', fontSize:'12px'}}>{r[2]}</td>
                    <td style={{padding:'10px 14px', fontFamily:'var(--mono)', fontSize:'12px', color:'var(--forest)', fontWeight:600}}>{r[3]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Demo>
        </div>
      </section>

      {/* Charts */}
      <section style={{padding:'48px 0', borderBottom:'1px solid var(--ink)'}}>
        <div className="wrap">
          <Eyebrow num="§E">Primitivă pentru grafice</Eyebrow>
          <h2 className="serif" style={{fontSize:'var(--fs-h1)', fontWeight:500, margin:'0 0 24px', letterSpacing:'-0.02em'}}>FT-style: restrâns, adnotat, citabil.</h2>
          <ul style={{fontSize:'14px', lineHeight:1.7, color:'var(--ink-2)', paddingLeft:'20px'}}>
            <li>Grilă orizontală subțire (opacitate 8%), linia zero la 30%.</li>
            <li>Ordine culori: forest → ochre → ink. Niciodată &gt; 3 serii pe grafic.</li>
            <li>Punct capăt cu valoare explicită (fără tooltip ca singură sursă).</li>
            <li>Adnotare în căsuță hârtie-2 cu serif italic pentru context.</li>
            <li>Cifrele mereu <span className="mono">tabular-nums</span>.</li>
          </ul>
        </div>
      </section>

      {/* Voice */}
      <section style={{padding:'48px 0', borderBottom:'1px solid var(--ink)'}}>
        <div className="wrap">
          <Eyebrow num="§F">Voce & ton</Eyebrow>
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:'24px'}}>
            <div style={{border:'1px solid var(--forest)', padding:'24px'}}>
              <div className="eyebrow" style={{color:'var(--forest)', marginBottom:'12px'}}>✓ DA</div>
              <ul className="serif" style={{fontSize:'17px', lineHeight:1.6, fontStyle:'italic', paddingLeft:'20px', margin:0}}>
                <li>„Unde merg banii tăi?"</li>
                <li>„Fiecare dreptunghi e banii tăi."</li>
                <li>„Lipsesc 5.8 mld MDL față de plan."</li>
                <li>„Cere-le socoteală."</li>
              </ul>
            </div>
            <div style={{border:'1px solid var(--bad)', padding:'24px'}}>
              <div className="eyebrow" style={{color:'var(--bad)', marginBottom:'12px'}}>✗ NU</div>
              <ul style={{fontSize:'15px', lineHeight:1.6, paddingLeft:'20px', margin:0, color:'var(--ink-3)', fontStyle:'italic'}}>
                <li>„Vizualizați KPI-urile noastre inovatoare"</li>
                <li>„Dashboard-ul furnizează insights"</li>
                <li>„Suntem dedicați transparenței"</li>
                <li>„Empowering citizens 🚀"</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function Swatch({v,h,u,dark}) {
  return (
    <div>
      <div style={{height:'72px', background: `var(${v})`, border:'1px solid var(--ink)'}}/>
      <div className="mono" style={{fontSize:'10px', color:'var(--ink-3)', marginTop:'8px'}}>{v}</div>
      <div className="mono" style={{fontSize:'10px', color:'var(--ink)', fontWeight:600}}>{h}</div>
      <div style={{fontSize:'11px', color:'var(--ink-3)', marginTop:'2px'}}>{u}</div>
    </div>
  );
}

function Demo({title, children}) {
  return (
    <div style={{border:'1px solid var(--ink)', padding:'20px', background:'var(--paper)'}}>
      <div className="mono" style={{fontSize:'10px', color:'var(--ink-3)', letterSpacing:'0.12em', textTransform:'uppercase', marginBottom:'16px'}}>{title}</div>
      {children}
    </div>
  );
}

window.SystemPage = SystemPage;
