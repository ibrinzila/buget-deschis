/* Budget Explorer page */

function BudgetPage({ tweaks }) {
  const [year, setYear] = useState(2024);
  const [view, setView] = useState('approved');
  const [selected, setSelected] = useState(null);
  const data = window.BUDGET_DATA_2024;
  const total = data.totalApproved;
  const sorted = [...data.sectors].sort((a,b) => b.approved - a.approved);

  return (
    <div style={{background:'var(--paper)', minHeight:'80vh'}}>
      <section style={{borderBottom:'1px solid var(--ink)', padding:'40px 0 32px'}}>
        <div className="wrap">
          <div className="mono" style={{fontSize:'11px', color:'var(--ink-3)', marginBottom:'12px'}}>PLATFORMĂ / §02 · BUGET</div>
          <div style={{display:'grid', gridTemplateColumns:'1.6fr 1fr', gap:'48px', alignItems:'end'}}>
            <div>
              <h1 className="serif" style={{fontSize:'var(--fs-d2)', lineHeight:0.95, fontWeight:400, letterSpacing:'-0.03em', margin:'0 0 16px'}}>
                Explorează <em style={{color:'var(--forest)'}}>fiecare leu</em> al Moldovei.
              </h1>
              <p style={{fontSize:'17px', lineHeight:1.55, color:'var(--ink-2)', margin:0, maxWidth:'560px'}}>
                Clasificare COFOG. Aprobat vs revizuit vs executat. 11 sectoare, 6 ani de istorie, clasificare funcțională ONU.
              </p>
            </div>
            <div style={{display:'flex', flexDirection:'column', gap:'16px'}}>
              <div>
                <div className="eyebrow" style={{marginBottom:'8px'}}>Anul fiscal</div>
                <div style={{display:'flex', border:'1px solid var(--ink)'}}>
                  {[2024,2023,2022,2021,2020,2019].map(y => (
                    <button key={y} onClick={()=>setYear(y)} style={{
                      flex:1, border:'none', padding:'10px',
                      background: year===y ? 'var(--ink)' : 'var(--paper)',
                      color: year===y ? 'var(--paper)' : 'var(--ink)',
                      fontFamily:'var(--mono)', fontSize:'12px', cursor:'pointer',
                      borderRight: y!==2019 ? '1px solid var(--ink)' : 'none',
                    }}>{y}</button>
                  ))}
                </div>
              </div>
              <div>
                <div className="eyebrow" style={{marginBottom:'8px'}}>Tip vizualizare</div>
                <div style={{display:'flex', border:'1px solid var(--ink)'}}>
                  {[['approved','Aprobat'],['revised','Revizuit'],['actual','Executat']].map(([k,l],i) => (
                    <button key={k} onClick={()=>setView(k)} style={{
                      flex:1, border:'none', padding:'10px',
                      background: view===k ? 'var(--forest)' : 'var(--paper)',
                      color: view===k ? 'var(--paper)' : 'var(--ink)',
                      fontFamily:'var(--sans)', fontSize:'12px', fontWeight:500, cursor:'pointer',
                      borderRight: i<2 ? '1px solid var(--ink)' : 'none',
                    }}>{l}</button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Summary row */}
      <section style={{borderBottom:'1px solid var(--ink)', background:'var(--paper-2)'}}>
        <div className="wrap" style={{display:'grid', gridTemplateColumns:'repeat(5, 1fr)', gap:0}}>
          {[
            { l:'Total aprobat', v:'100.0', u:'mld MDL', sub:'↑ 7.4% vs 2023', tone:'forest'},
            { l:'Executat', v:'94.2', u:'mld MDL', sub:'93.1% rată execuție', tone:'forest'},
            { l:'Top sector', v:'Protecția Socială', u:null, sub:'28.5% din buget', tone:'ink'},
            { l:'Fonduri UE', v:'9.4', u:'mld MDL', sub:'↑ 20.5% vs 2023', tone:'ochre'},
            { l:'Pe cetățean', v:'~38 000', u:'lei/an', sub:'la 2.6M locuitori', tone:'ink'},
          ].map((s,i) => (
            <div key={i} style={{padding:'28px 24px', borderRight: i<4 ? '1px solid var(--ink)' : 'none'}}>
              <div className="eyebrow" style={{marginBottom:'10px'}}>{s.l}</div>
              <div className="serif" style={{fontSize:'32px', lineHeight:1, fontWeight:500, color: s.tone==='forest'?'var(--forest)':s.tone==='ochre'?'var(--ochre)':'var(--ink)', letterSpacing:'-0.02em'}}>
                {s.v}{s.u && <span className="mono" style={{fontSize:'12px', color:'var(--ink-3)', fontWeight:400, marginLeft:'6px'}}>{s.u}</span>}
              </div>
              <div style={{fontSize:'11px', color:'var(--ink-3)', marginTop:'6px'}}>{s.sub}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Main treemap + detail */}
      <section style={{padding:'56px 0', borderBottom:'1px solid var(--ink)'}}>
        <div className="wrap">
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'end', marginBottom:'24px'}}>
            <div>
              <Eyebrow num="A">Distribuție pe sector</Eyebrow>
              <h2 className="serif" style={{fontSize:'var(--fs-h1)', fontWeight:500, letterSpacing:'-0.02em', margin:0}}>
                Compoziție funcțională · {year}
              </h2>
            </div>
            <div style={{display:'flex', gap:'8px'}}>
              <button className="btn btn-ghost" style={{borderColor:'var(--ink)', border:'1px solid var(--ink)'}}>↓ CSV</button>
              <button className="btn btn-ghost" style={{borderColor:'var(--ink)', border:'1px solid var(--ink)'}}>↓ JSON</button>
              <button className="btn btn-ghost" style={{borderColor:'var(--ink)', border:'1px solid var(--ink)'}}>Share ↗</button>
            </div>
          </div>

          <div style={{display:'grid', gridTemplateColumns:'2.4fr 1fr', gap:'24px'}}>
            <BudgetTreemap sorted={sorted} total={total} view={view} onSelect={setSelected} selected={selected}/>
            <SectorDetail sector={selected || sorted[0]} total={total} year={year}/>
          </div>
        </div>
      </section>

      {/* Data table */}
      <section style={{padding:'56px 0', borderBottom:'1px solid var(--ink)'}}>
        <div className="wrap">
          <Eyebrow num="B">Tabel detaliat</Eyebrow>
          <h2 className="serif" style={{fontSize:'var(--fs-h1)', fontWeight:500, letterSpacing:'-0.02em', margin:'0 0 24px'}}>
            Toate datele, toate sectoarele.
          </h2>
          <div style={{border:'1px solid var(--ink)', background:'var(--paper)'}}>
            <table style={{width:'100%', borderCollapse:'collapse'}}>
              <thead>
                <tr style={{borderBottom:'1px solid var(--ink)', background:'var(--paper-2)'}}>
                  {['COFOG','Sector','Aprobat','Executat','Execuție','Pondere',''].map((h,i) => (
                    <th key={i} style={{textAlign: i>=2&&i<=5?'right':'left', padding:'12px 16px', fontFamily:'var(--mono)', fontSize:'10px', letterSpacing:'0.1em', textTransform:'uppercase', color:'var(--ink-3)', fontWeight:600}}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {sorted.map(s => {
                  const exec = s.actual/s.approved*100;
                  return (
                    <tr key={s.id} style={{borderBottom:'1px solid var(--rule)', cursor:'pointer'}}
                      onMouseEnter={e=>e.currentTarget.style.background='var(--paper-2)'}
                      onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                      <td style={{padding:'14px 16px', fontFamily:'var(--mono)', fontSize:'12px', color:'var(--ink-3)'}}>{s.code}</td>
                      <td style={{padding:'14px 16px'}}>
                        <div style={{display:'flex', alignItems:'center', gap:'12px'}}>
                          <span style={{width:'10px', height:'10px', background:s.color, flexShrink:0}}/>
                          <span style={{fontSize:'14px', fontWeight:500}}>{s.name}</span>
                        </div>
                      </td>
                      <td style={{padding:'14px 16px', textAlign:'right', fontFamily:'var(--mono)', fontSize:'13px'}}>{fmt.mdl(s.approved)}</td>
                      <td style={{padding:'14px 16px', textAlign:'right', fontFamily:'var(--mono)', fontSize:'13px'}}>{fmt.mdl(s.actual)}</td>
                      <td style={{padding:'14px 16px', textAlign:'right'}}>
                        <div style={{display:'inline-flex', alignItems:'center', gap:'8px'}}>
                          <div style={{width:'60px', height:'4px', background:'var(--paper-2)', border:'1px solid var(--rule)'}}>
                            <div style={{height:'100%', width:`${Math.min(exec,100)}%`, background: exec>=90?'var(--good)':exec>=75?'var(--warn)':'var(--bad)'}}/>
                          </div>
                          <span className="mono" style={{fontSize:'12px', fontWeight:600, color: exec>=90?'var(--good)':exec>=75?'var(--warn)':'var(--bad)'}}>{exec.toFixed(1)}%</span>
                        </div>
                      </td>
                      <td style={{padding:'14px 16px', textAlign:'right', fontFamily:'var(--mono)', fontSize:'13px', color:'var(--ink-3)'}}>{(s.approved/total*100).toFixed(1)}%</td>
                      <td style={{padding:'14px 16px', textAlign:'right', color:'var(--ink-3)'}}>→</td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr style={{background:'var(--ink)', color:'var(--paper)'}}>
                  <td style={{padding:'14px 16px', fontFamily:'var(--mono)', fontSize:'11px'}}>Σ</td>
                  <td style={{padding:'14px 16px', fontWeight:600}}>Total</td>
                  <td style={{padding:'14px 16px', textAlign:'right', fontFamily:'var(--mono)', fontWeight:600}}>{fmt.mdl(total)}</td>
                  <td style={{padding:'14px 16px', textAlign:'right', fontFamily:'var(--mono)', fontWeight:600}}>{fmt.mdl(data.totalActual)}</td>
                  <td style={{padding:'14px 16px', textAlign:'right', fontFamily:'var(--mono)', fontWeight:600, color:'var(--ochre-3)'}}>93.1%</td>
                  <td style={{padding:'14px 16px', textAlign:'right', fontFamily:'var(--mono)', fontWeight:600}}>100%</td>
                  <td/>
                </tr>
              </tfoot>
            </table>
          </div>
          <p style={{fontSize:'11px', color:'var(--ink-3)', marginTop:'16px', fontStyle:'italic'}}>
            Sursă: Ministerul Finanțelor al Republicii Moldova · Banca Mondială BOOST · Actualizat lunar
          </p>
        </div>
      </section>
    </div>
  );
}

function BudgetTreemap({sorted, total, view, onSelect, selected}) {
  // Simple flex-row packing
  const col1 = sorted.slice(0, 3);
  const col2 = sorted.slice(3, 7);
  const col3 = sorted.slice(7);
  const Block = ({s}) => {
    const pct = s.approved/total*100;
    const isSel = selected?.id === s.id;
    return (
      <button onClick={()=>onSelect(s)} style={{
        background: s.color, color:'var(--paper)', border:'none', textAlign:'left',
        padding: pct>15?'18px':'12px', display:'flex', flexDirection:'column', justifyContent:'space-between',
        cursor:'pointer', outline: isSel ? '3px solid var(--ochre)' : '1px solid var(--ink)', outlineOffset: isSel?'-3px':'-1px',
        transition:'filter 0.15s', fontFamily:'var(--sans)',
      }}
      onMouseEnter={e => e.currentTarget.style.filter='brightness(1.1)'}
      onMouseLeave={e => e.currentTarget.style.filter='none'}>
        <div>
          <div className="mono" style={{fontSize:'10px', opacity:0.7}}>COFOG · {s.code}</div>
          <div className="serif" style={{fontSize: pct>15?'26px':pct>8?'18px':'14px', fontWeight:500, lineHeight:1.1, marginTop:'4px', letterSpacing:'-0.01em'}}>{s.name}</div>
        </div>
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'baseline', marginTop:'12px'}}>
          <span className="mono" style={{fontSize: pct>15?'24px':pct>8?'18px':'13px', fontWeight:700}}>{pct.toFixed(1)}%</span>
          <span className="mono" style={{fontSize:'10px', opacity:0.8}}>{fmt.mdl(s.approved)} mil</span>
        </div>
      </button>
    );
  };
  return (
    <div style={{background:'var(--ink)', display:'grid', gridTemplateColumns:'2.8fr 1.6fr 1fr', gap:'1px', height:'560px', border:'1px solid var(--ink)'}}>
      <div style={{display:'grid', gridTemplateRows: col1.map(s=>`${s.approved}fr`).join(' '), gap:'1px'}}>{col1.map(s=><Block key={s.id} s={s}/>)}</div>
      <div style={{display:'grid', gridTemplateRows: col2.map(s=>`${s.approved}fr`).join(' '), gap:'1px'}}>{col2.map(s=><Block key={s.id} s={s}/>)}</div>
      <div style={{display:'grid', gridTemplateRows: col3.map(s=>`${s.approved}fr`).join(' '), gap:'1px'}}>{col3.map(s=><Block key={s.id} s={s}/>)}</div>
    </div>
  );
}

function SectorDetail({sector, total, year}) {
  if (!sector) return null;
  const exec = sector.actual/sector.approved*100;
  return (
    <div style={{border:'1px solid var(--ink)', padding:'24px', background:'var(--paper)', position:'sticky', top:'88px', height:'560px', overflowY:'auto', display:'flex', flexDirection:'column'}}>
      <div className="mono" style={{fontSize:'10px', color:'var(--ink-3)', letterSpacing:'0.12em'}}>COFOG {sector.code} · {year}</div>
      <h3 className="serif" style={{fontSize:'28px', fontWeight:500, letterSpacing:'-0.02em', margin:'6px 0 6px', lineHeight:1.05}}>{sector.name}</h3>
      <p style={{fontSize:'13px', color:'var(--ink-3)', margin:'0 0 20px', fontStyle:'italic'}}>{sector.story}</p>

      <div style={{background:'var(--paper-2)', padding:'16px', marginBottom:'16px'}}>
        <div className="eyebrow" style={{marginBottom:'6px'}}>Alocat · {((sector.approved/total)*100).toFixed(1)}% din buget</div>
        <div className="serif" style={{fontSize:'36px', fontWeight:500, color:sector.color, lineHeight:1, letterSpacing:'-0.02em'}}>
          {fmt.mdl(sector.approved)} <span className="mono" style={{fontSize:'12px', color:'var(--ink-3)', fontWeight:400}}>mil MDL</span>
        </div>
      </div>

      <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:'12px', marginBottom:'20px'}}>
        <div style={{border:'1px solid var(--rule)', padding:'12px'}}>
          <div className="eyebrow">Executat</div>
          <div className="mono" style={{fontSize:'18px', fontWeight:600, color:'var(--forest)', marginTop:'4px'}}>{fmt.mdl(sector.actual)}</div>
        </div>
        <div style={{border:'1px solid var(--rule)', padding:'12px'}}>
          <div className="eyebrow">Rată execuție</div>
          <div className="mono" style={{fontSize:'18px', fontWeight:600, color: exec>=90?'var(--good)':exec>=75?'var(--warn)':'var(--bad)', marginTop:'4px'}}>{exec.toFixed(1)}%</div>
        </div>
      </div>

      {/* Mini yearly sparkline */}
      <div style={{marginBottom:'16px'}}>
        <div className="eyebrow" style={{marginBottom:'8px'}}>Tendință 2019 → 2024</div>
        <svg viewBox="0 0 200 50" style={{width:'100%', height:'50px'}}>
          {[0.4,0.55,0.68,0.82,0.92,1].map((v,i,arr) => {
            if (i===0) return null;
            return <line key={i} x1={(i-1)/5*200} y1={50-arr[i-1]*40} x2={i/5*200} y2={50-v*40} stroke={sector.color} strokeWidth="2"/>;
          })}
          {[0.4,0.55,0.68,0.82,0.92,1].map((v,i) => <circle key={i} cx={i/5*200} cy={50-v*40} r="2.5" fill="var(--paper)" stroke={sector.color} strokeWidth="1.5"/>)}
        </svg>
      </div>

      <div style={{marginTop:'auto', display:'flex', flexDirection:'column', gap:'8px'}}>
        <button className="btn" style={{fontSize:'12px', padding:'10px', justifyContent:'center'}}>Vezi toate subcategoriile →</button>
        <button className="btn btn-ghost" style={{fontSize:'11px', justifyContent:'center'}}>↓ CSV sector</button>
      </div>
    </div>
  );
}

window.BudgetPage = BudgetPage;
