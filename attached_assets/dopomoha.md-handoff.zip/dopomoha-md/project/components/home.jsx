/* Home page — Editorial hero + living treemap */

function HomePage({ setPage, tweaks }) {
  const data = window.BUDGET_DATA_2024;
  const trend = window.BUDGET_TREND;
  const [hoverSector, setHoverSector] = useState(null);

  // Treemap layout (squarified-ish simple row packing)
  const sorted = [...data.sectors].sort((a,b) => b.approved - a.approved);
  const total = data.totalApproved;

  return (
    <div>
      {/* HERO */}
      <section style={{position:'relative', background:'var(--paper)', overflow:'hidden'}}>
        <div className="wrap" style={{padding:'48px 24px 40px'}}>
          <div style={{display:'grid', gridTemplateColumns:'1.3fr 1fr', gap:'60px', alignItems:'end'}}>
            <div>
              <div style={{display:'flex', alignItems:'center', gap:'14px', marginBottom:'28px'}} className="rise">
                <span className="mono" style={{fontSize:'11px', letterSpacing:'0.12em', color:'var(--ink-3)'}}>VOL. 06 · ED. {new Date().toLocaleDateString('ro-RO', {day:'2-digit', month:'2-digit', year:'numeric'})}</span>
                <div style={{flex:1, height:'1px', background:'var(--ink)', opacity:0.3}}/>
                <span className="tag tag-dot tag-live">MTender live · {new Date().toLocaleTimeString('ro-RO', {hour:'2-digit', minute:'2-digit'})}</span>
              </div>

              <h1 className="serif rise rise-1" style={{fontSize:'var(--fs-d1)', lineHeight:0.95, fontWeight:400, letterSpacing:'-0.03em', margin:'0 0 28px', color:'var(--ink)'}}>
                Unde merg <em style={{color:'var(--forest)', fontStyle:'italic'}}>cei 100 de miliarde</em> <br/>ai Moldovei?
              </h1>

              <p className="rise rise-2" style={{fontSize:'19px', lineHeight:1.5, color:'var(--ink-2)', maxWidth:'560px', margin:'0 0 36px'}}>
                Bugetul de stat, achizițiile publice și contractele guvernamentale — toate într-un loc, actualizate zilnic, complet libere.
                <strong style={{color:'var(--ink)', fontWeight:600}}> Ianuarie 2024 – Decembrie 2024.</strong>
              </p>

              <div className="rise rise-3" style={{display:'flex', gap:'12px', flexWrap:'wrap'}}>
                <button className="btn btn-forest" onClick={() => setPage('budget')}>
                  Explorează bugetul →
                </button>
                <button className="btn" onClick={() => setPage('procurement')}>
                  Caută în achiziții
                </button>
                <button className="btn btn-ghost" onClick={() => setPage('tour')}>
                  <span style={{display:'inline-block', width:'20px', height:'20px', borderRadius:'999px', background:'var(--ochre)', color:'var(--ink)', display:'inline-grid', placeItems:'center', fontSize:'10px', marginRight:'4px'}}>▶</span>
                  Tur ghidat · 5 min
                </button>
              </div>
            </div>

            {/* Hero side: Budget at a glance counter */}
            <div className="rise rise-3" style={{borderLeft:'1px solid var(--ink)', paddingLeft:'32px'}}>
              <div className="eyebrow" style={{marginBottom:'12px'}}>Bugetul 2024, pe scurt</div>
              <div className="serif" style={{fontSize:'var(--fs-d2)', lineHeight:0.9, fontWeight:500, margin:'0 0 4px', color:'var(--forest)'}}>
                <CountUp to={100} decimals={1} />
                <span className="mono" style={{fontSize:'18px', color:'var(--ink-3)', fontWeight:400, fontFamily:'var(--mono)', marginLeft:'6px', fontStyle:'normal'}}>mld MDL</span>
              </div>
              <p style={{fontSize:'13px', color:'var(--ink-3)', margin:'4px 0 24px'}}>≈ 5,1 mld €  ·  38 000 lei pe cetățean</p>

              <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:'16px 24px'}}>
                <MiniStat label="Executat" value={<><CountUp to={94.2} decimals={1} /> mld</>} sub="93.1% din aprobat" color="var(--forest)"/>
                <MiniStat label="Achiziții 2024" value="41.8 mld" sub="112 380 proceduri" color="var(--ochre)"/>
                <MiniStat label="Open Budget Index" value="81/100" sub="locul 5 mondial ↑" color="var(--ink)"/>
                <MiniStat label="Fonduri UE" value="9.4 mld" sub="↑ 20.5% vs 2023" color="var(--ink)"/>
              </div>
            </div>
          </div>
        </div>
        <div style={{borderTop:'1px solid var(--ink)'}} />
      </section>

      {/* LIVING TREEMAP hero data */}
      <section style={{background:'var(--paper)', padding:'72px 0 40px'}}>
        <div className="wrap">
          <div style={{display:'grid', gridTemplateColumns:'1fr 2.2fr', gap:'48px', alignItems:'start'}}>
            <div style={{position:'sticky', top:'88px'}}>
              <Eyebrow num="§01">Compoziția bugetului</Eyebrow>
              <h2 className="serif" style={{fontSize:'var(--fs-h1)', lineHeight:1.05, fontWeight:500, letterSpacing:'-0.02em', margin:'0 0 20px'}}>
                Fiecare dreptunghi e un sector. Dimensiunea <em style={{color:'var(--forest)'}}>e banii tăi</em>.
              </h2>
              <p style={{fontSize:'15px', lineHeight:1.6, color:'var(--ink-2)', margin:'0 0 20px'}}>
                Clasificare COFOG a Națiunilor Unite. 11 sectoare funcționale. Trei dintre ele — Protecția Socială, Educația și Sănătatea — absorb <strong>62%</strong> din bugetul 2024.
              </p>
              {hoverSector && (
                <div className="card card-pad" style={{background:'var(--paper-2)', border:'1px solid var(--ink)'}}>
                  <div className="eyebrow">COFOG {hoverSector.code}</div>
                  <h3 className="serif" style={{fontSize:'22px', margin:'4px 0 6px', fontWeight:500}}>{hoverSector.name}</h3>
                  <p style={{fontSize:'13px', color:'var(--ink-3)', margin:'0 0 14px'}}>{hoverSector.story}</p>
                  <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:'8px'}}>
                    <div><div className="mono" style={{fontSize:'10px', color:'var(--ink-3)'}}>APROBAT</div><div className="mono" style={{fontSize:'18px'}}>{fmt.mdl(hoverSector.approved)} <span style={{fontSize:'11px', color:'var(--ink-3)'}}>mil</span></div></div>
                    <div><div className="mono" style={{fontSize:'10px', color:'var(--ink-3)'}}>EXECUTAT</div><div className="mono" style={{fontSize:'18px'}}>{fmt.mdl(hoverSector.actual)} <span style={{fontSize:'11px', color:'var(--ink-3)'}}>mil</span></div></div>
                  </div>
                  <div style={{marginTop:'14px', paddingTop:'14px', borderTop:'1px solid var(--rule)', fontSize:'13px', color:'var(--ink-2)'}}>
                    <strong>{fmt.pct(hoverSector.approved/total*100)}</strong> din buget · <strong>{fmt.mdl(Math.round(hoverSector.approved/2.5))} lei</strong> pe cetățean
                  </div>
                </div>
              )}
              {!hoverSector && <p style={{fontSize:'13px', color:'var(--ink-4)', fontStyle:'italic', marginTop:'16px'}}>→ Treceți cursorul peste un sector pentru detalii</p>}
            </div>

            <HomeTreemap sorted={sorted} total={total} onHover={setHoverSector} />
          </div>
        </div>
      </section>

      {/* TREND CHART */}
      <section style={{background:'var(--paper-2)', padding:'72px 0', borderTop:'1px solid var(--ink)', borderBottom:'1px solid var(--ink)'}}>
        <div className="wrap">
          <Eyebrow num="§02">Tendință · 2019–2024</Eyebrow>
          <div style={{display:'grid', gridTemplateColumns:'1fr 2fr', gap:'48px', alignItems:'end', marginBottom:'32px'}}>
            <h2 className="serif" style={{fontSize:'var(--fs-h1)', lineHeight:1.05, fontWeight:500, letterSpacing:'-0.02em', margin:'0'}}>
              Bugetul a crescut cu <em style={{color:'var(--forest)'}}>61%</em> în șase ani.
            </h2>
            <p style={{fontSize:'15px', lineHeight:1.6, color:'var(--ink-2)', margin:0}}>
              De la 62.3 la 100.0 miliarde MDL în termeni nominali. Fondurile UE au crescut de <strong>4,5× </strong>în aceeași perioadă, semnalând acces intensificat la finanțare europeană.
            </p>
          </div>
          <TrendChart data={trend} />
        </div>
      </section>

      {/* WHAT YOU CAN DO — feature grid */}
      <section style={{background:'var(--paper)', padding:'72px 0'}}>
        <div className="wrap">
          <Eyebrow num="§03">Instrumente</Eyebrow>
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:'32px', marginBottom:'40px'}}>
            <h2 className="serif" style={{fontSize:'var(--fs-h1)', lineHeight:1.05, fontWeight:500, letterSpacing:'-0.02em', margin:0}}>
              Ce poți face cu datele de pe platformă?
            </h2>
            <p style={{fontSize:'16px', lineHeight:1.6, color:'var(--ink-2)', margin:0, alignSelf:'end'}}>
              Pentru cetățeni curioși, jurnaliști, cercetători și oricine vrea să înțeleagă cum sunt cheltuiți banii publici.
            </p>
          </div>
          <div style={{display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap:'0', border:'1px solid var(--ink)'}}>
            {[
              { n:'01', t:'Explorator buget', d:'Vizualizează alocările pe sector, compară aprobat vs executat, urmărește tendințe 2019 → prezent.', go:'budget' },
              { n:'02', t:'Achiziții publice', d:'Caută printre 385K+ proceduri MTender. Filtre pe autoritate, sector, status, metodă.', go:'procurement' },
              { n:'03', t:'Tururi narative', d:'Povești ghidate de 5 minute care te poartă prin date, sector cu sector, decizie cu decizie.', go:'tour', badge:'NOU' },
              { n:'04', t:'Open Data API', d:'CSV, JSON, OCDS 1.1. API public documentat. Licență CC0 — public domain.', go:'about' },
            ].map((f, i) => (
              <div key={f.n} onClick={() => setPage(f.go)}
                style={{
                  padding:'32px 24px',
                  borderRight: i<3 ? '1px solid var(--ink)' : 'none',
                  cursor:'pointer',
                  background:'var(--paper)',
                  transition:'background 0.2s',
                  position:'relative',
                  minHeight:'280px',
                  display:'flex', flexDirection:'column',
                }}
                onMouseEnter={e => e.currentTarget.style.background='var(--paper-2)'}
                onMouseLeave={e => e.currentTarget.style.background='var(--paper)'}
              >
                {f.badge && <span className="tag" style={{position:'absolute', top:'16px', right:'16px', background:'var(--ochre)', borderColor:'var(--ochre-2)'}}>{f.badge}</span>}
                <div className="mono" style={{fontSize:'10px', letterSpacing:'0.15em', color:'var(--ink-3)', marginBottom:'24px'}}>— {f.n}</div>
                <h3 className="serif" style={{fontSize:'22px', fontWeight:500, letterSpacing:'-0.01em', margin:'0 0 12px'}}>{f.t}</h3>
                <p style={{fontSize:'13px', lineHeight:1.55, color:'var(--ink-2)', margin:'0 0 auto'}}>{f.d}</p>
                <div style={{marginTop:'24px', fontSize:'12px', fontWeight:600, color:'var(--forest)'}}>Deschide →</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CITIZEN CALCULATOR — the joy */}
      <section style={{background:'var(--ink)', color:'var(--paper)', padding:'80px 0', position:'relative', overflow:'hidden'}}>
        <div className="wrap">
          <CitizenCalc />
        </div>
      </section>

      {/* HIGHLIGHTS — like editorial callouts */}
      <section style={{background:'var(--paper)', padding:'72px 0', borderTop:'1px solid var(--ink)'}}>
        <div className="wrap">
          <Eyebrow num="§04">De reținut</Eyebrow>
          <h2 className="serif" style={{fontSize:'var(--fs-h1)', lineHeight:1.05, fontWeight:500, letterSpacing:'-0.02em', margin:'0 0 40px', maxWidth:'700px'}}>
            Trei cifre care definesc anul bugetar 2024.
          </h2>
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:'0', borderTop:'1px solid var(--ink)'}}>
            <HighlightBlock num="01" stat="+61%" label="Creștere buget 2019→2024" body="De la 62.3 la 100.0 mld MDL. În termeni reali, corectat cu inflația, creșterea e de aproximativ 28%."/>
            <HighlightBlock num="02" stat="81/100" label="Scor Open Budget Survey 2023" body="Moldova a urcat de pe locul 47 pe locul 5 global între 2017 și 2023. Singura țară est-europeană în top 5."/>
            <HighlightBlock num="03" stat="385K" label="Proceduri MTender 2018–2024" body="Valoare cumulată: 113 mld MDL. Rata de competitivitate a crescut de la 61% (2018) la 74% (2024)." last/>
          </div>
        </div>
      </section>

      {/* CTA strip */}
      <section style={{background:'var(--forest)', color:'var(--paper)', padding:'56px 0'}}>
        <div className="wrap" style={{display:'flex', justifyContent:'space-between', alignItems:'center', gap:'40px'}}>
          <div>
            <div className="mono" style={{fontSize:'11px', letterSpacing:'0.12em', textTransform:'uppercase', color:'var(--ochre-3)', marginBottom:'12px'}}>Platformă open source</div>
            <h3 className="serif" style={{fontSize:'36px', fontWeight:400, fontStyle:'italic', margin:0, lineHeight:1.1, maxWidth:'700px'}}>
              Codul e public, datele-s CC0. <br/>Contribuie, copiază, remixează.
            </h3>
          </div>
          <div style={{display:'flex', gap:'12px', flexShrink:0}}>
            <a className="btn" style={{background:'var(--paper)', color:'var(--ink)', borderColor:'var(--paper)'}} href="#">GitHub →</a>
            <a className="btn" style={{background:'transparent', borderColor:'var(--paper-3)', color:'var(--paper)'}} href="#">Metodologie</a>
          </div>
        </div>
      </section>
    </div>
  );
}

function MiniStat({label, value, sub, color}) {
  return (
    <div>
      <div className="mono" style={{fontSize:'10px', letterSpacing:'0.1em', color:'var(--ink-3)', textTransform:'uppercase', marginBottom:'4px'}}>{label}</div>
      <div className="serif" style={{fontSize:'22px', fontWeight:500, color: color||'var(--ink)', lineHeight:1.1}}>{value}</div>
      <div style={{fontSize:'11px', color:'var(--ink-3)', marginTop:'2px'}}>{sub}</div>
    </div>
  );
}

function HighlightBlock({num, stat, label, body, last}) {
  return (
    <div style={{padding:'32px 24px', borderRight: last ? 'none' : '1px solid var(--ink)', borderBottom:'1px solid var(--ink)'}}>
      <div className="mono" style={{fontSize:'10px', color:'var(--ink-3)', marginBottom:'24px'}}>— {num}</div>
      <div className="serif" style={{fontSize:'64px', lineHeight:0.9, fontWeight:400, color:'var(--forest)', margin:'0 0 8px', letterSpacing:'-0.03em'}}>{stat}</div>
      <div className="eyebrow" style={{marginBottom:'16px'}}>{label}</div>
      <p style={{fontSize:'14px', lineHeight:1.55, color:'var(--ink-2)', margin:0}}>{body}</p>
    </div>
  );
}

// Treemap using simple nested flexbox layout — big sectors left, small right
function HomeTreemap({sorted, total, onHover}) {
  // split into columns
  const col1 = sorted.slice(0, 3); // top 3 get big row
  const col2 = sorted.slice(3, 7);
  const col3 = sorted.slice(7);

  const Block = ({s, style}) => {
    const pct = s.approved / total * 100;
    return (
      <div
        onMouseEnter={() => onHover(s)}
        onMouseLeave={() => onHover(null)}
        style={{
          background: s.color,
          color: 'var(--paper)',
          padding: '14px',
          display:'flex', flexDirection:'column', justifyContent:'space-between',
          cursor:'pointer',
          transition:'transform 0.2s ease, filter 0.2s',
          outline:'1px solid var(--ink)',
          ...style,
        }}
      >
        <div>
          <div className="mono" style={{fontSize:'10px', letterSpacing:'0.1em', opacity:0.7}}>{s.code}</div>
          <div className="serif" style={{fontSize: pct>15 ? '28px' : pct>8 ? '20px' : '14px', fontWeight:500, lineHeight:1.1, marginTop:'4px', letterSpacing:'-0.01em'}}>
            {s.name}
          </div>
        </div>
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'baseline', gap:'8px'}}>
          <span className="mono" style={{fontSize: pct>15?'22px':pct>8?'16px':'12px', fontWeight:600}}>{pct.toFixed(1)}%</span>
          <span className="mono" style={{fontSize:'10px', opacity:0.7}}>{fmt.mdl(s.approved)} mil</span>
        </div>
      </div>
    );
  };

  return (
    <div style={{border:'1px solid var(--ink)', background:'var(--ink)', display:'grid', gridTemplateColumns:'2.8fr 1.8fr 1fr', gap:'1px', height:'560px'}}>
      <div style={{display:'grid', gridTemplateRows: `${col1[0].approved}fr ${col1[1].approved}fr ${col1[2].approved}fr`, gap:'1px'}}>
        {col1.map(s => <Block key={s.id} s={s}/>)}
      </div>
      <div style={{display:'grid', gridTemplateRows: col2.map(s=>`${s.approved}fr`).join(' '), gap:'1px'}}>
        {col2.map(s => <Block key={s.id} s={s}/>)}
      </div>
      <div style={{display:'grid', gridTemplateRows: col3.map(s=>`${s.approved}fr`).join(' '), gap:'1px'}}>
        {col3.map(s => <Block key={s.id} s={s}/>)}
      </div>
    </div>
  );
}

// Simple editorial-style line/area chart
function TrendChart({data}) {
  const w = 1200, h = 380;
  const padL = 60, padR = 80, padT = 20, padB = 40;
  const iw = w - padL - padR, ih = h - padT - padB;
  const max = 110;
  const xs = data.map((_,i) => padL + i/(data.length-1) * iw);
  const y = v => padT + ih - (v/max) * ih;
  const apPath = data.map((d,i) => `${i===0?'M':'L'} ${xs[i]} ${y(d.approved)}`).join(' ');
  const acPath = data.map((d,i) => `${i===0?'M':'L'} ${xs[i]} ${y(d.actual)}`).join(' ');
  const euPath = data.map((d,i) => `${i===0?'M':'L'} ${xs[i]} ${y(d.euFunds)}`).join(' ');
  const apArea = apPath + ` L ${xs[xs.length-1]} ${y(0)} L ${xs[0]} ${y(0)} Z`;

  return (
    <div style={{position:'relative', background:'var(--paper)', border:'1px solid var(--ink)', padding:'24px'}}>
      <div style={{display:'flex', gap:'24px', marginBottom:'8px', fontSize:'12px'}}>
        <span style={{display:'inline-flex', alignItems:'center', gap:'8px'}}><span style={{display:'inline-block', width:'16px', height:'3px', background:'var(--forest)'}}/>Aprobat</span>
        <span style={{display:'inline-flex', alignItems:'center', gap:'8px'}}><span style={{display:'inline-block', width:'16px', height:'3px', background:'var(--ink)', opacity:0.5, borderStyle:'dashed'}}/>Executat</span>
        <span style={{display:'inline-flex', alignItems:'center', gap:'8px'}}><span style={{display:'inline-block', width:'16px', height:'3px', background:'var(--ochre)'}}/>Fonduri UE</span>
        <span className="mono" style={{marginLeft:'auto', fontSize:'10px', color:'var(--ink-3)'}}>mld MDL</span>
      </div>
      <svg viewBox={`0 0 ${w} ${h}`} style={{width:'100%', height:'auto', display:'block'}}>
        {/* y grid */}
        {[0, 25, 50, 75, 100].map(v => (
          <g key={v}>
            <line x1={padL} x2={w-padR} y1={y(v)} y2={y(v)} stroke="var(--ink)" strokeOpacity={v===0?0.3:0.08}/>
            <text x={padL-10} y={y(v)+4} textAnchor="end" fontFamily="var(--mono)" fontSize="11" fill="var(--ink-3)">{v}</text>
          </g>
        ))}
        {/* area under approved */}
        <path d={apArea} fill="var(--forest)" fillOpacity="0.08"/>
        <path d={apPath} stroke="var(--forest)" strokeWidth="2.5" fill="none"/>
        <path d={acPath} stroke="var(--ink)" strokeWidth="1.5" fill="none" strokeDasharray="4 3" opacity="0.6"/>
        <path d={euPath} stroke="var(--ochre)" strokeWidth="2" fill="none"/>
        {/* points & labels */}
        {data.map((d,i) => (
          <g key={d.year}>
            <circle cx={xs[i]} cy={y(d.approved)} r="4" fill="var(--paper)" stroke="var(--forest)" strokeWidth="2"/>
            <text x={xs[i]} y={h-padB+22} textAnchor="middle" fontFamily="var(--mono)" fontSize="11" fill="var(--ink-2)">{d.year}</text>
          </g>
        ))}
        {/* endpoint labels */}
        <g>
          <text x={xs[xs.length-1]+10} y={y(data[data.length-1].approved)+4} fontFamily="var(--serif)" fontSize="14" fontWeight="500" fill="var(--forest)">100.0</text>
          <text x={xs[xs.length-1]+10} y={y(data[data.length-1].actual)+4} fontFamily="var(--serif)" fontSize="13" fill="var(--ink-3)">94.2</text>
          <text x={xs[xs.length-1]+10} y={y(data[data.length-1].euFunds)+4} fontFamily="var(--serif)" fontSize="13" fill="var(--ochre-2)" fontWeight="500">9.4</text>
        </g>
        {/* annotation */}
        <g>
          <line x1={xs[3]} x2={xs[3]} y1={y(data[3].euFunds)+4} y2={y(data[3].euFunds)+40} stroke="var(--ink-3)" strokeWidth="0.5"/>
          <rect x={xs[3]-70} y={y(data[3].euFunds)+40} width="180" height="40" fill="var(--paper-2)" stroke="var(--ink-3)" strokeWidth="0.5"/>
          <text x={xs[3]-62} y={y(data[3].euFunds)+56} fontFamily="var(--serif)" fontStyle="italic" fontSize="12" fill="var(--ink)">2022: Candidatura UE</text>
          <text x={xs[3]-62} y={y(data[3].euFunds)+70} fontFamily="var(--sans)" fontSize="11" fill="var(--ink-3)">Accelerarea fondurilor de aderare</text>
        </g>
      </svg>
    </div>
  );
}

// Citizen calculator — the "actionable joy" feature
function CitizenCalc() {
  const [income, setIncome] = useState(12000);
  const taxRate = 0.18; // simplified avg income tax + social
  const vatShare = 0.10;
  const annual = income * 12;
  const taxPaid = annual * taxRate + annual * vatShare;

  const sectors = window.BUDGET_DATA_2024.sectors;
  const total = window.BUDGET_DATA_2024.totalApproved;
  const myShare = sectors.map(s => ({
    ...s,
    mine: Math.round(taxPaid * (s.approved/total))
  })).sort((a,b) => b.mine - a.mine);

  return (
    <div style={{display:'grid', gridTemplateColumns:'1fr 1.4fr', gap:'60px', alignItems:'start'}}>
      <div>
        <div className="mono" style={{fontSize:'11px', letterSpacing:'0.15em', color:'var(--ochre-3)', marginBottom:'16px'}}>§05 · PARTEA TA</div>
        <h2 className="serif" style={{fontSize:'var(--fs-h1)', lineHeight:1.05, fontWeight:400, margin:'0 0 20px', letterSpacing:'-0.02em'}}>
          Dacă câștigi <em style={{color:'var(--ochre-3)', fontStyle:'italic'}}>{fmt.mdl(income)} lei</em> pe lună...
        </h2>
        <p style={{fontSize:'15px', lineHeight:1.6, color:'var(--paper-3)', margin:'0 0 28px'}}>
          ...contribui aproximativ <strong style={{color:'var(--paper)'}}>{fmt.mdl(Math.round(taxPaid))} lei pe an</strong> la bugetul Moldovei, prin impozit pe venit, contribuții sociale și TVA.
          <br/><br/>
          Iată unde merg banii tăi, proporțional cu bugetul 2024:
        </p>
        <div style={{marginBottom:'16px'}}>
          <label className="eyebrow" style={{color:'var(--ochre-3)'}}>Venit lunar net (lei)</label>
          <input type="range" min="5000" max="50000" step="1000" value={income} onChange={e=>setIncome(+e.target.value)}
            style={{width:'100%', marginTop:'12px', accentColor:'var(--ochre)'}}/>
          <div style={{display:'flex', justifyContent:'space-between', fontSize:'11px', color:'var(--paper-3)', marginTop:'4px'}}>
            <span className="mono">5 000</span>
            <span className="mono" style={{color:'var(--ochre)'}}>{fmt.mdl(income)}</span>
            <span className="mono">50 000</span>
          </div>
        </div>
        <div style={{fontSize:'11px', color:'var(--ink-4)', fontStyle:'italic'}}>
          * Estimare aprox: 18% impozit+contribuții + 10% din cheltuielile de consum (TVA). Pentru calcul exact consultă un contabil.
        </div>
      </div>

      <div style={{background:'var(--paper)', color:'var(--ink)', padding:'32px', border:'1px solid var(--ochre)'}}>
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:'4px'}}>
          <div className="eyebrow">Anual contribui aprox.</div>
          <div className="mono" style={{fontSize:'10px', color:'var(--ink-3)'}}>ESTIMAT</div>
        </div>
        <div className="serif" style={{fontSize:'52px', lineHeight:1, fontWeight:500, color:'var(--forest)', margin:'4px 0 24px', letterSpacing:'-0.02em'}}>
          {fmt.mdl(Math.round(taxPaid))} <span className="mono" style={{fontSize:'16px', color:'var(--ink-3)', fontWeight:400, fontStyle:'normal'}}>lei</span>
        </div>
        <div style={{borderTop:'1px solid var(--ink)', paddingTop:'16px'}}>
          {myShare.slice(0,7).map(s => (
            <div key={s.id} style={{display:'grid', gridTemplateColumns:'120px 1fr 80px', gap:'12px', alignItems:'center', padding:'8px 0', borderBottom:'1px solid var(--rule)'}}>
              <div style={{fontSize:'13px', fontWeight:500}}>{s.name}</div>
              <div style={{height:'6px', background:'var(--paper-2)', position:'relative'}}>
                <div style={{position:'absolute', left:0, top:0, bottom:0, width:`${(s.approved/total)*100*3}%`, background:s.color, maxWidth:'100%'}}/>
              </div>
              <div className="mono" style={{fontSize:'13px', textAlign:'right', fontWeight:600}}>{fmt.mdl(s.mine)} lei</div>
            </div>
          ))}
        </div>
        <button className="btn" style={{marginTop:'20px', width:'100%', justifyContent:'center'}}>
          ↓ Descarcă chitanța ta (PDF)
        </button>
      </div>
    </div>
  );
}

window.HomePage = HomePage;
