/* About + Tour + System pages */

function AboutPage() {
  return (
    <div style={{background:'var(--paper)'}}>
      <section style={{borderBottom:'1px solid var(--ink)', padding:'56px 0'}}>
        <div className="wrap-narrow">
          <div className="mono" style={{fontSize:'11px', color:'var(--ink-3)', marginBottom:'16px'}}>PLATFORMĂ / §04 · DESPRE</div>
          <h1 className="serif" style={{fontSize:'var(--fs-d2)', lineHeight:0.95, fontWeight:400, letterSpacing:'-0.03em', margin:'0 0 24px'}}>
            De ce <em style={{color:'var(--forest)'}}>transparența</em> bugetară nu e un lux.
          </h1>
          <p style={{fontSize:'20px', lineHeight:1.5, color:'var(--ink-2)', margin:'0 0 40px', maxWidth:'680px'}}>
            E un drept fundamental. Fiecare cetățean plătește pentru acest buget — prin impozit, prin TVA, prin muncă. E drept elementar să știe unde merg banii.
          </p>
          <div style={{display:'flex', gap:'12px'}}>
            <button className="btn btn-forest">Citește metodologia →</button>
            <button className="btn">Cohesion Lab ↗</button>
          </div>
        </div>
      </section>

      <section style={{padding:'64px 0', borderBottom:'1px solid var(--ink)'}}>
        <div className="wrap-narrow">
          <Eyebrow num="01">Misiune</Eyebrow>
          <p className="serif" style={{fontSize:'28px', lineHeight:1.3, fontWeight:400, margin:'0 0 32px', color:'var(--ink-2)', fontStyle:'italic', letterSpacing:'-0.01em'}}>
            „Credem că datele publice sunt ale publicului. Platforma face datele bugetare și de achiziții accesibile oricărui cetățean, jurnalist sau cercetător — fără bariere tehnice sau legale."
          </p>
          <p style={{fontSize:'15px', color:'var(--ink-3)', fontStyle:'italic'}}>— Echipa Cohesion Lab, 2024</p>
        </div>
      </section>

      <section style={{padding:'64px 0', borderBottom:'1px solid var(--ink)', background:'var(--paper-2)'}}>
        <div className="wrap">
          <Eyebrow num="02">Surse de date</Eyebrow>
          <h2 className="serif" style={{fontSize:'var(--fs-h1)', fontWeight:500, margin:'0 0 32px', letterSpacing:'-0.02em'}}>
            Patru surse oficiale, zero scraping.
          </h2>
          <div style={{display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap:0, border:'1px solid var(--ink)', background:'var(--paper)'}}>
            {[
              { t:'MTender', s:'e-procurement.gov.md', d:'Sistem național de achiziții electronice. Conformitate OCDS 1.1. Actualizări zilnice via API oficial.', f:'JSON, XML, CSV'},
              { t:'Ministerul Finanțelor', s:'mf.gov.md', d:'Date lunare de execuție bugetară, Legea bugetului de stat, Bugetul Cetățeanului.', f:'PDF, XLSX → parsed'},
              { t:'BOOST Moldova', s:'datacatalog.worldbank.org', d:'Baza de date World Bank de cheltuieli publice cu clasificare multidimensională.', f:'CSV, STATA'},
              { t:'Curtea de Conturi', s:'ccrm.md', d:'Rapoarte de audit financiar și de conformitate pentru instituțiile publice.', f:'PDF → extracted'},
            ].map((src,i) => (
              <div key={src.t} style={{padding:'28px 24px', borderRight: i<3?'1px solid var(--ink)':'none'}}>
                <div className="mono" style={{fontSize:'10px', color:'var(--ink-3)', marginBottom:'12px'}}>SURSA · {String(i+1).padStart(2,'0')}</div>
                <h3 className="serif" style={{fontSize:'22px', fontWeight:500, margin:'0 0 4px'}}>{src.t}</h3>
                <div className="mono" style={{fontSize:'11px', color:'var(--forest)', marginBottom:'12px'}}>{src.s}</div>
                <p style={{fontSize:'13px', lineHeight:1.5, color:'var(--ink-2)', margin:'0 0 12px'}}>{src.d}</p>
                <div style={{fontSize:'11px', color:'var(--ink-3)', fontFamily:'var(--mono)'}}>Format: {src.f}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section style={{padding:'64px 0', borderBottom:'1px solid var(--ink)'}}>
        <div className="wrap">
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:'48px'}}>
            <div>
              <Eyebrow num="03">Metodologie</Eyebrow>
              <h2 className="serif" style={{fontSize:'var(--fs-h2)', fontWeight:500, margin:'0 0 20px', letterSpacing:'-0.02em'}}>
                Cum procesăm datele.
              </h2>
              <ol style={{paddingLeft:'0', listStyle:'none', fontSize:'15px', lineHeight:1.7, color:'var(--ink-2)'}}>
                {[
                  ['Colectare', 'Datele sunt preluate automat via API-uri oficiale. Nu scraping — doar surse agreate.'],
                  ['Normalizare', 'Clasificare funcțională COFOG (ONU). Monedă MDL curentă, fără ajustare de inflație.'],
                  ['Validare', 'Sume încrucișate cu rapoartele CCRM. Discrepanțe &gt; 1% sunt semnalate public.'],
                  ['Publicare', 'Licență CC0. API public documentat. Zero autentificare necesară pentru citire.'],
                ].map((step,i) => (
                  <li key={i} style={{display:'grid', gridTemplateColumns:'40px 1fr', gap:'16px', padding:'12px 0', borderTop:'1px solid var(--rule)'}}>
                    <div className="mono" style={{fontSize:'13px', fontWeight:600, color:'var(--ochre)'}}>{String(i+1).padStart(2,'0')}</div>
                    <div><strong>{step[0]}.</strong> {step[1]}</div>
                  </li>
                ))}
              </ol>
            </div>
            <div>
              <Eyebrow num="04">Open Source</Eyebrow>
              <h2 className="serif" style={{fontSize:'var(--fs-h2)', fontWeight:500, margin:'0 0 20px', letterSpacing:'-0.02em'}}>
                Tot codul, toate datele.
              </h2>
              <p style={{fontSize:'15px', lineHeight:1.6, color:'var(--ink-2)', margin:'0 0 20px'}}>
                Sursa platformei e publicată pe GitHub sub licență <strong>EUPL-1.2</strong> (European Union Public Licence). Datele — sub <strong>CC0</strong>. Contribuțiile sunt bine-venite.
              </p>
              <div style={{display:'flex', flexDirection:'column', gap:'8px'}}>
                <a className="btn" href="#" style={{justifyContent:'space-between'}}>GitHub · buget-deschis <span>↗</span></a>
                <a className="btn" href="#" style={{justifyContent:'space-between'}}>Licență EUPL-1.2 <span>↗</span></a>
                <a className="btn" href="#" style={{justifyContent:'space-between'}}>Issues & roadmap <span>↗</span></a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

// Narrative tour — 5-minute guided story
function TourPage() {
  const [step, setStep] = useState(0);
  const steps = [
    {
      kicker: 'Tur ghidat · Pas 1 / 6 · ≈ 5 min',
      title: 'Întrebarea simplă',
      lead: 'În 2024, bugetul Moldovei a fost de 100 de miliarde de lei. Asta înseamnă 38 000 lei pentru fiecare cetățean — inclusiv copii.',
      body: 'Pentru comparație: salariul mediu net în Moldova e 14 500 lei pe lună. Bugetul per capita echivalează cu 2.6 salarii medii anuale pe fiecare cap de om.',
      visual: 'ratio',
    },
    {
      kicker: 'Pas 2 / 6',
      title: 'Unde merg acești 100 mld?',
      lead: 'Protecția Socială consumă 28.5%. Educația — 18.2%. Sănătatea — 15.8%. Împreună: 62.5 mld MDL, peste 6 lei din 10.',
      body: 'Aceste trei sectoare sunt considerate „cheltuieli sociale esențiale" în metodologia ONU. În Franța ponderea e 65%; în Ucraina — 52%.',
      visual: 'trio',
    },
    {
      kicker: 'Pas 3 / 6',
      title: 'Apărarea a crescut cel mai rapid',
      lead: 'De la 2.2 mld MDL în 2019 la 4.1 mld în 2024 — o creștere de 86% în termeni nominali, cea mai accelerată dintre toate sectoarele.',
      body: 'Contextul: invazia din februarie 2022, proximitatea frontului, obligațiile de aderare la UE. Ponderea din PIB a urcat de la 0.3% la 0.6%.',
      visual: 'defense',
    },
    {
      kicker: 'Pas 4 / 6',
      title: 'Fondurile UE au explodat',
      lead: '2.1 mld MDL în 2019 → 9.4 mld MDL în 2024. De 4,5 ori mai mulți bani europeni în buget.',
      body: 'Candidatura oficială pentru UE (iunie 2022) a deblocat pachetul de Asistență de Aderare. Acestea nu sunt împrumuturi — sunt granturi nerambursabile.',
      visual: 'eu',
    },
    {
      kicker: 'Pas 5 / 6',
      title: '93% executat. Cine nu a cheltuit?',
      lead: 'Bugetul total executat în 2024: 94.2 mld din 100 aprobate. Lipsesc 5.8 mld MDL — aproximativ un buget al Apărării.',
      body: 'Cea mai mică rată de execuție: Datoria Publică (80%). Asta înseamnă că am economisit pe dobânzi — vești bune pentru stabilitatea fiscală.',
      visual: 'exec',
    },
    {
      kicker: 'Pas 6 / 6 · Finalul turului',
      title: 'Ce poți face acum?',
      lead: 'Ai parcurs cei 100 de miliarde. Datele sunt ale tale — descarcă-le, analizează-le, cere-le socoteală.',
      body: 'Poți continua să explorezi: treemap interactiv pe pagina Buget, căutare în 385K proceduri pe pagina Achiziții, calculator personal pe Acasă.',
      visual: 'final',
    },
  ];
  const s = steps[step];

  return (
    <div style={{background:'var(--ink)', color:'var(--paper)', minHeight:'calc(100vh - 64px)', display:'flex', flexDirection:'column'}}>
      {/* progress */}
      <div style={{padding:'16px 0', borderBottom:'1px solid #2a2a25'}}>
        <div className="wrap">
          <div style={{display:'grid', gridTemplateColumns:`repeat(${steps.length}, 1fr)`, gap:'4px'}}>
            {steps.map((_,i) => (
              <div key={i} style={{height:'3px', background: i<=step?'var(--ochre)':'#2a2a25'}}/>
            ))}
          </div>
        </div>
      </div>

      <div className="wrap" style={{padding:'64px 24px', flex:1, display:'grid', gridTemplateColumns:'1fr 1fr', gap:'60px', alignItems:'center'}}>
        <div key={step} className="rise">
          <div className="mono" style={{fontSize:'11px', letterSpacing:'0.15em', color:'var(--ochre-3)', marginBottom:'20px'}}>{s.kicker}</div>
          <h1 className="serif" style={{fontSize:'clamp(40px, 5vw, 64px)', lineHeight:1, fontWeight:400, letterSpacing:'-0.02em', margin:'0 0 24px'}}>
            {s.title}
          </h1>
          <p className="serif" style={{fontSize:'24px', lineHeight:1.3, fontWeight:400, fontStyle:'italic', color:'var(--paper)', margin:'0 0 20px'}}>
            {s.lead}
          </p>
          <p style={{fontSize:'15px', lineHeight:1.6, color:'var(--paper-3)', margin:'0 0 40px', maxWidth:'500px'}}>
            {s.body}
          </p>
          <div style={{display:'flex', gap:'12px', alignItems:'center'}}>
            <button className="btn" onClick={()=>setStep(Math.max(0,step-1))} disabled={step===0}
              style={{background:'transparent', borderColor:'var(--paper-3)', color: step===0?'var(--ink-3)':'var(--paper)', opacity: step===0?0.4:1}}>← Înapoi</button>
            {step < steps.length-1 ? (
              <button className="btn btn-ochre" onClick={()=>setStep(step+1)}>Continuă →</button>
            ) : (
              <button className="btn btn-ochre" onClick={()=>setStep(0)}>Reia turul ↻</button>
            )}
            <span className="mono" style={{fontSize:'11px', color:'var(--ink-3)', marginLeft:'auto'}}>{step+1} / {steps.length}</span>
          </div>
        </div>

        <div key={'v'+step} className="rise rise-1" style={{aspectRatio:'1', position:'relative', display:'grid', placeItems:'center'}}>
          <TourVisual type={s.visual}/>
        </div>
      </div>
    </div>
  );
}

function TourVisual({type}) {
  if (type === 'ratio') {
    return (
      <div style={{textAlign:'center'}}>
        <div className="serif" style={{fontSize:'160px', lineHeight:0.9, color:'var(--ochre)', fontWeight:400, letterSpacing:'-0.04em'}}>38 000</div>
        <div className="mono" style={{fontSize:'13px', color:'var(--paper-3)', letterSpacing:'0.2em', marginTop:'8px'}}>LEI / CETĂȚEAN / AN</div>
        <div style={{marginTop:'40px', display:'flex', gap:'2px', justifyContent:'center'}}>
          {Array(26).fill(0).map((_,i) => <div key={i} style={{width:'8px', height:'40px', background: i<26?'var(--forest)':'#333'}}/>)}
        </div>
        <div className="mono" style={{fontSize:'11px', color:'var(--paper-3)', marginTop:'12px'}}>≈ 2.6 salarii medii anuale</div>
      </div>
    );
  }
  if (type === 'trio') {
    return (
      <div style={{width:'100%', display:'grid', gridTemplateColumns:'28.5fr 18.2fr 15.8fr', gap:'2px', height:'400px'}}>
        <div style={{background:'var(--d-social)', padding:'20px', display:'flex', flexDirection:'column', justifyContent:'flex-end'}}>
          <div className="serif" style={{fontSize:'56px', fontWeight:500, color:'var(--paper)', lineHeight:0.9}}>28.5%</div>
          <div className="mono" style={{fontSize:'11px', color:'var(--paper)', opacity:0.9, marginTop:'6px'}}>PROTECȚIE SOCIALĂ</div>
        </div>
        <div style={{background:'var(--d-education)', padding:'16px', display:'flex', flexDirection:'column', justifyContent:'flex-end'}}>
          <div className="serif" style={{fontSize:'40px', fontWeight:500, color:'var(--paper)', lineHeight:0.9}}>18.2%</div>
          <div className="mono" style={{fontSize:'10px', color:'var(--paper)', opacity:0.9, marginTop:'6px'}}>EDUCAȚIE</div>
        </div>
        <div style={{background:'var(--d-health)', padding:'14px', display:'flex', flexDirection:'column', justifyContent:'flex-end'}}>
          <div className="serif" style={{fontSize:'34px', fontWeight:500, color:'var(--paper)', lineHeight:0.9}}>15.8%</div>
          <div className="mono" style={{fontSize:'10px', color:'var(--paper)', opacity:0.9, marginTop:'6px'}}>SĂNĂTATE</div>
        </div>
      </div>
    );
  }
  if (type === 'defense') {
    const vals = [2.2, 2.4, 2.7, 3.1, 3.6, 4.1];
    const years = [2019,2020,2021,2022,2023,2024];
    const max = 4.5;
    return (
      <div style={{width:'100%'}}>
        <div style={{display:'grid', gridTemplateColumns:'repeat(6,1fr)', gap:'6px', height:'280px', alignItems:'end'}}>
          {vals.map((v,i) => (
            <div key={i} style={{display:'flex', flexDirection:'column', alignItems:'center', gap:'8px'}}>
              <div className="mono" style={{fontSize:'11px', color:'var(--ochre)'}}>{v}</div>
              <div style={{width:'100%', height:`${v/max*100}%`, background: i===5?'var(--ochre)':'var(--d-defense)', transition:'all 0.3s'}}/>
              <div className="mono" style={{fontSize:'10px', color:'var(--paper-3)'}}>{years[i]}</div>
            </div>
          ))}
        </div>
        <div className="serif" style={{fontSize:'40px', color:'var(--ochre)', marginTop:'24px', fontStyle:'italic', textAlign:'center'}}>+86% în 6 ani</div>
      </div>
    );
  }
  if (type === 'eu') {
    return (
      <div style={{textAlign:'center'}}>
        <div style={{display:'flex', alignItems:'end', justifyContent:'center', gap:'80px'}}>
          <div>
            <div className="serif" style={{fontSize:'90px', color:'var(--paper-3)', fontWeight:400, lineHeight:0.9}}>2.1</div>
            <div className="mono" style={{fontSize:'11px', color:'var(--paper-3)', marginTop:'8px'}}>2019 · mld MDL</div>
          </div>
          <div className="serif" style={{fontSize:'48px', color:'var(--ochre)', fontStyle:'italic'}}>→ ×4.5</div>
          <div>
            <div className="serif" style={{fontSize:'140px', color:'var(--ochre)', fontWeight:400, lineHeight:0.9, letterSpacing:'-0.04em'}}>9.4</div>
            <div className="mono" style={{fontSize:'11px', color:'var(--ochre-3)', marginTop:'8px'}}>2024 · mld MDL</div>
          </div>
        </div>
        <div className="mono" style={{fontSize:'11px', color:'var(--paper-3)', marginTop:'32px', letterSpacing:'0.15em'}}>FONDURI UE · NERAMBURSABILE</div>
      </div>
    );
  }
  if (type === 'exec') {
    return (
      <div style={{width:'100%'}}>
        <svg viewBox="0 0 400 400" style={{width:'100%'}}>
          <circle cx="200" cy="200" r="140" fill="none" stroke="#333" strokeWidth="40"/>
          <circle cx="200" cy="200" r="140" fill="none" stroke="var(--forest)" strokeWidth="40"
            strokeDasharray={`${2*Math.PI*140*0.931} ${2*Math.PI*140}`}
            transform="rotate(-90 200 200)"/>
          <text x="200" y="190" textAnchor="middle" fontFamily="var(--serif)" fontSize="80" fill="var(--paper)" fontWeight="500">93.1%</text>
          <text x="200" y="225" textAnchor="middle" fontFamily="var(--mono)" fontSize="12" fill="var(--paper-3)" letterSpacing="0.15em">EXECUȚIE 2024</text>
        </svg>
        <div className="mono" style={{fontSize:'11px', color:'var(--paper-3)', textAlign:'center', marginTop:'12px'}}>— Lipsesc 5.8 mld MDL față de plan —</div>
      </div>
    );
  }
  // final
  return (
    <div style={{textAlign:'center'}}>
      <div className="serif" style={{fontSize:'140px', color:'var(--ochre)', fontStyle:'italic', lineHeight:1, fontWeight:400}}>Gata.</div>
      <p className="serif" style={{fontSize:'22px', color:'var(--paper-3)', marginTop:'24px', fontStyle:'italic'}}>Ai văzut ce trebuia văzut.<br/>Acum explorează singur.</p>
    </div>
  );
}

window.AboutPage = AboutPage;
window.TourPage = TourPage;
