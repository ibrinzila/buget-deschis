/* Procurement page */
function ProcurementPage() {
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('all');
  const [sector, setSector] = useState('all');
  const tenders = window.TENDERS;
  const sectors = [...new Set(tenders.map(t => t.sector))];
  const results = tenders.filter(t =>
    (q === '' || t.title.toLowerCase().includes(q.toLowerCase()) || t.authority.toLowerCase().includes(q.toLowerCase())) &&
    (status === 'all' || t.status === status) &&
    (sector === 'all' || t.sector === sector)
  );
  const totalVolume = tenders.reduce((a,t) => a+t.value, 0);
  const flagged = tenders.filter(t => t.flag).length;

  const sectorVolumes = sectors.map(s => ({
    sector: s,
    volume: tenders.filter(t => t.sector === s).reduce((a,t) => a+t.value, 0),
    count: tenders.filter(t => t.sector === s).length,
  })).sort((a,b) => b.volume - a.volume);
  const maxVol = Math.max(...sectorVolumes.map(s => s.volume));

  return (
    <div style={{background:'var(--paper)'}}>
      <section style={{borderBottom:'1px solid var(--ink)', padding:'40px 0 32px'}}>
        <div className="wrap">
          <div className="mono" style={{fontSize:'11px', color:'var(--ink-3)', marginBottom:'12px'}}>PLATFORMĂ / §03 · ACHIZIȚII</div>
          <h1 className="serif" style={{fontSize:'var(--fs-d2)', lineHeight:0.95, fontWeight:400, letterSpacing:'-0.03em', margin:'0 0 16px'}}>
            Cine cumpără, <em style={{color:'var(--forest)'}}>de la cine</em>, cu ce bani?
          </h1>
          <p style={{fontSize:'17px', lineHeight:1.55, color:'var(--ink-2)', margin:0, maxWidth:'680px'}}>
            Date în timp real din platforma MTender. 112 380 proceduri în 2024. Standardul OCDS 1.1 — același folosit de Marea Britanie, Ucraina și Mexic.
          </p>
        </div>
      </section>

      {/* Stats */}
      <section style={{borderBottom:'1px solid var(--ink)', background:'var(--paper-2)'}}>
        <div className="wrap" style={{display:'grid', gridTemplateColumns:'repeat(6, 1fr)', gap:0}}>
          {[
            { l:'Proceduri', v:'112 380', sub:'anul 2024'},
            { l:'Active acum', v:'3 214', sub:'se închid în 30 zile', tone:'forest'},
            { l:'Atribuite', v:'98 401', sub:'contracte semnate', tone:'forest'},
            { l:'Anulate', v:'2 187', sub:'1.9% din total', tone:'bad'},
            { l:'Volum total', v:'41.8 mld', sub:'MDL · 2024'},
            { l:'Rată competitivă', v:'74%', sub:'≥ 2 ofertanți', tone:'ochre'},
          ].map((s,i) => (
            <div key={i} style={{padding:'24px 20px', borderRight: i<5?'1px solid var(--ink)':'none'}}>
              <div className="eyebrow" style={{marginBottom:'8px'}}>{s.l}</div>
              <div className="serif" style={{fontSize:'26px', lineHeight:1, fontWeight:500, color: s.tone==='forest'?'var(--forest)':s.tone==='bad'?'var(--bad)':s.tone==='ochre'?'var(--ochre)':'var(--ink)', letterSpacing:'-0.02em'}}>{s.v}</div>
              <div style={{fontSize:'11px', color:'var(--ink-3)', marginTop:'4px'}}>{s.sub}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Flagged anomalies callout */}
      <section style={{padding:'40px 0', borderBottom:'1px solid var(--ink)'}}>
        <div className="wrap">
          <div style={{border:'1px solid var(--ochre)', padding:'24px', background:'var(--paper)', display:'grid', gridTemplateColumns:'auto 1fr auto', gap:'24px', alignItems:'center'}}>
            <div style={{width:'48px', height:'48px', background:'var(--ochre)', color:'var(--ink)', display:'grid', placeItems:'center', fontSize:'24px', fontFamily:'var(--serif)', fontStyle:'italic', fontWeight:600}}>!</div>
            <div>
              <div className="eyebrow" style={{marginBottom:'4px', color:'var(--ochre-2)'}}>Semnalizat automat</div>
              <div style={{fontSize:'16px', fontWeight:600}}>{flagged} proceduri cu risc în rezultatele actuale</div>
              <div style={{fontSize:'13px', color:'var(--ink-3)', marginTop:'4px'}}>Ofertant unic, tip „achiziție directă" de mare valoare, sau concurență scăzută (≤2 ofertanți pe contracte &gt; 20M).</div>
            </div>
            <button className="btn btn-ochre">Arată doar acestea →</button>
          </div>
        </div>
      </section>

      {/* Search + table */}
      <section style={{padding:'40px 0', borderBottom:'1px solid var(--ink)'}}>
        <div className="wrap">
          <div style={{display:'grid', gridTemplateColumns:'1fr auto auto auto', gap:'12px', marginBottom:'24px'}}>
            <div style={{position:'relative'}}>
              <span style={{position:'absolute', left:'14px', top:'50%', transform:'translateY(-50%)', color:'var(--ink-3)'}}>⌕</span>
              <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Caută după obiect, autoritate contractantă, furnizor…"
                style={{width:'100%', padding:'14px 16px 14px 40px', border:'1px solid var(--ink)', background:'var(--paper)', fontFamily:'var(--sans)', fontSize:'14px'}}/>
            </div>
            <select value={status} onChange={e=>setStatus(e.target.value)} style={{padding:'12px 14px', border:'1px solid var(--ink)', background:'var(--paper)', fontFamily:'var(--sans)', fontSize:'13px'}}>
              <option value="all">Toate statusurile</option>
              <option value="active">Active</option>
              <option value="awarded">Atribuite</option>
              <option value="cancelled">Anulate</option>
            </select>
            <select value={sector} onChange={e=>setSector(e.target.value)} style={{padding:'12px 14px', border:'1px solid var(--ink)', background:'var(--paper)', fontFamily:'var(--sans)', fontSize:'13px'}}>
              <option value="all">Toate sectoarele</option>
              {sectors.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            <button className="btn" onClick={()=>{setQ('');setStatus('all');setSector('all');}}>Resetează</button>
          </div>

          <div className="mono" style={{fontSize:'11px', color:'var(--ink-3)', marginBottom:'12px'}}>
            {results.length} rezultate din {tenders.length} · Total volum: {fmt.mdl(Math.round(results.reduce((a,t)=>a+t.value,0)/1e6))} mil MDL
          </div>

          <div style={{border:'1px solid var(--ink)', background:'var(--paper)', overflow:'hidden'}}>
            <table style={{width:'100%', borderCollapse:'collapse'}}>
              <thead>
                <tr style={{background:'var(--paper-2)', borderBottom:'1px solid var(--ink)'}}>
                  {['ID','Obiect','Autoritate','Valoare','Metodă','Status','Data','Ofertanți'].map((h,i) => (
                    <th key={h} style={{textAlign: i===3?'right':'left', padding:'12px 14px', fontFamily:'var(--mono)', fontSize:'10px', letterSpacing:'0.1em', textTransform:'uppercase', color:'var(--ink-3)', fontWeight:600}}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {results.map(t => (
                  <tr key={t.id} style={{borderBottom:'1px solid var(--rule)', cursor:'pointer'}}
                    onMouseEnter={e=>e.currentTarget.style.background='var(--paper-2)'}
                    onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                    <td style={{padding:'14px', fontFamily:'var(--mono)', fontSize:'11px', color:'var(--forest)'}}>{t.id}</td>
                    <td style={{padding:'14px', maxWidth:'340px'}}>
                      <div style={{fontSize:'13px', fontWeight:500, lineHeight:1.4}}>{t.title}</div>
                      <div style={{fontSize:'11px', color:'var(--ink-3)', marginTop:'2px'}}>{t.sector}</div>
                    </td>
                    <td style={{padding:'14px', fontSize:'12px', color:'var(--ink-2)'}}>{t.authority}</td>
                    <td style={{padding:'14px', textAlign:'right', fontFamily:'var(--mono)', fontSize:'13px', fontWeight:600}}>{(t.value/1e6).toFixed(2)} <span style={{color:'var(--ink-3)', fontWeight:400}}>mil</span></td>
                    <td style={{padding:'14px'}}>
                      <span style={{fontFamily:'var(--mono)', fontSize:'10px', padding:'3px 8px', border:'1px solid var(--ink)', background: t.method==='open'?'var(--paper)':t.method==='direct'?'var(--bad)':'var(--warn)', color: t.method==='open'?'var(--ink)':'var(--paper)'}}>
                        {t.method==='open'?'DESCHIS':t.method==='direct'?'DIRECT':'LIMITAT'}
                      </span>
                    </td>
                    <td style={{padding:'14px'}}>
                      <span style={{fontFamily:'var(--mono)', fontSize:'10px', padding:'3px 8px', border:'1px solid', borderColor: t.status==='active'?'var(--forest)':t.status==='cancelled'?'var(--bad)':'var(--ink)', color: t.status==='active'?'var(--forest)':t.status==='cancelled'?'var(--bad)':'var(--ink)'}}>
                        {t.status==='active'?'ACTIV':t.status==='awarded'?'ATRIBUIT':'ANULAT'}
                      </span>
                      {t.flag && <span style={{marginLeft:'6px', fontSize:'10px', color:'var(--ochre-2)'}}>⚐</span>}
                    </td>
                    <td style={{padding:'14px', fontFamily:'var(--mono)', fontSize:'11px', color:'var(--ink-3)'}}>{t.date}</td>
                    <td style={{padding:'14px', fontFamily:'var(--mono)', fontSize:'13px', fontWeight:600, textAlign:'center'}}>{t.bids || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Sector bar chart */}
      <section style={{padding:'56px 0', borderBottom:'1px solid var(--ink)'}}>
        <div className="wrap">
          <Eyebrow num="A">Volum pe sector</Eyebrow>
          <h2 className="serif" style={{fontSize:'var(--fs-h1)', fontWeight:500, margin:'0 0 32px', letterSpacing:'-0.02em'}}>
            Transportul și Sănătatea cumpără cel mai mult în 2024.
          </h2>
          <div style={{display:'flex', flexDirection:'column', gap:'8px'}}>
            {sectorVolumes.map(s => (
              <div key={s.sector} style={{display:'grid', gridTemplateColumns:'160px 1fr 120px 60px', gap:'16px', alignItems:'center'}}>
                <div style={{fontSize:'14px', fontWeight:500}}>{s.sector}</div>
                <div style={{height:'28px', background:'var(--paper-2)', position:'relative'}}>
                  <div style={{position:'absolute', left:0, top:0, bottom:0, width:`${s.volume/maxVol*100}%`, background:'var(--forest)'}}/>
                  <div className="mono" style={{position:'absolute', left:'12px', top:'50%', transform:'translateY(-50%)', color:'var(--paper)', fontSize:'11px', fontWeight:600, textShadow:'0 0 2px var(--forest)'}}>
                    {(s.volume/1e6).toFixed(1)} mil MDL
                  </div>
                </div>
                <div className="mono" style={{fontSize:'11px', color:'var(--ink-3)'}}>{s.count} proceduri</div>
                <div className="mono" style={{fontSize:'11px', color:'var(--ink-3)', textAlign:'right'}}>{((s.volume/totalVolume)*100).toFixed(1)}%</div>
              </div>
            ))}
          </div>
          <p style={{fontSize:'11px', color:'var(--ink-3)', marginTop:'24px', fontStyle:'italic'}}>
            Sursă: MTender API (OCDS 1.1) · Actualizat zilnic la 04:00 EEST
          </p>
        </div>
      </section>
    </div>
  );
}

window.ProcurementPage = ProcurementPage;
