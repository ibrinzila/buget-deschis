/* Shared UI components */
const { useState, useEffect, useRef, useMemo } = React;

// Animated count-up
function CountUp({ to, duration = 1200, decimals = 0, suffix = '', prefix = '' }) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    const start = performance.now();
    let raf;
    const tick = (now) => {
      const p = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setVal(to * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [to, duration]);
  return <span className="tnum">{prefix}{val.toFixed(decimals).replace(/\B(?=(\d{3})+(?!\d))/g, ' ')}{suffix}</span>;
}

function Eyebrow({ children, num }) {
  return (
    <div style={{display:'flex', alignItems:'center', gap:'10px', marginBottom:'16px'}}>
      {num && <span className="mono" style={{fontSize:'11px', color:'var(--ink-3)'}}>{num}</span>}
      <div style={{flex: num ? '0 0 24px' : '0', height:'1px', background:'var(--ink)', opacity: num ? 0.3 : 0}} />
      <span className="eyebrow">{children}</span>
    </div>
  );
}

function Nav({ page, setPage }) {
  const items = [
    { id: 'home', label: 'Acasă', num: '01' },
    { id: 'budget', label: 'Buget', num: '02' },
    { id: 'procurement', label: 'Achiziții', num: '03' },
    { id: 'about', label: 'Despre', num: '04' },
    { id: 'system', label: 'Design System', num: '05' },
  ];
  return (
    <header style={{position:'sticky', top:0, zIndex:50, background:'var(--paper)', borderBottom:'1px solid var(--ink)'}}>
      <style>{`
        @media (max-width: 1180px) {
          .bd-header-subtitle { display: none; }
          .bd-nav-label { display: none; }
          .bd-nav-btn { padding: 8px 10px !important; }
        }
        @media (max-width: 900px) {
          .bd-lang { display: none !important; }
        }
      `}</style>
      <div className="wrap" style={{display:'flex', alignItems:'center', justifyContent:'space-between', height:'64px', gap:'16px'}}>
        <div style={{display:'flex', alignItems:'center', gap:'14px', cursor:'pointer', flexShrink:0}} onClick={() => setPage('home')}>
          <div style={{width:'32px', height:'32px', background:'var(--forest)', color:'var(--paper)', display:'grid', placeItems:'center', fontFamily:'var(--serif)', fontWeight:700, fontSize:'18px', fontStyle:'italic', flexShrink:0}}>b</div>
          <div style={{lineHeight:1.1}}>
            <div className="serif" style={{fontSize:'17px', fontWeight:600, letterSpacing:'-0.01em', whiteSpace:'nowrap'}}>Buget Deschis</div>
            <div className="mono bd-header-subtitle" style={{fontSize:'10px', color:'var(--ink-3)', letterSpacing:'0.1em', textTransform:'uppercase', whiteSpace:'nowrap'}}>Moldova · 2024</div>
          </div>
        </div>
        <nav style={{display:'flex', gap:'2px', flexShrink:1, minWidth:0}}>
          {items.map(it => (
            <button key={it.id} onClick={() => setPage(it.id)}
              className="bd-nav-btn"
              style={{
                background: page===it.id ? 'var(--ink)' : 'transparent',
                color: page===it.id ? 'var(--paper)' : 'var(--ink)',
                border: 'none',
                padding: '8px 14px',
                fontFamily: 'var(--sans)',
                fontSize: '13px',
                fontWeight: 500,
                cursor: 'pointer',
                letterSpacing:'-0.005em',
                display:'flex', alignItems:'center', gap:'8px',
                whiteSpace:'nowrap',
              }}>
              <span className="mono" style={{fontSize:'9px', opacity:0.6}}>{it.num}</span>
              <span className="bd-nav-label">{it.label}</span>
            </button>
          ))}
        </nav>
        <div style={{display:'flex', alignItems:'center', gap:'10px', flexShrink:0}}>
          <div className="mono bd-lang" style={{display:'flex', gap:'4px', fontSize:'11px'}}>
            <button style={{background:'var(--ink)', color:'var(--paper)', border:'none', padding:'4px 8px', cursor:'pointer', fontFamily:'var(--mono)', fontSize:'10px'}}>RO</button>
            <button style={{background:'transparent', color:'var(--ink-3)', border:'none', padding:'4px 8px', cursor:'pointer', fontFamily:'var(--mono)', fontSize:'10px'}}>RU</button>
            <button style={{background:'transparent', color:'var(--ink-3)', border:'none', padding:'4px 8px', cursor:'pointer', fontFamily:'var(--mono)', fontSize:'10px'}}>EN</button>
          </div>
        </div>
      </div>
    </header>
  );
}

function Footer() {
  return (
    <footer style={{background:'var(--ink)', color:'var(--paper)', padding:'56px 0 32px'}}>
      <div className="wrap">
        <div style={{display:'grid', gridTemplateColumns:'2fr 1fr 1fr 1fr', gap:'40px', marginBottom:'40px'}}>
          <div>
            <div className="serif" style={{fontSize:'32px', fontStyle:'italic', fontWeight:400, marginBottom:'16px', lineHeight:1.1}}>
              Unde merg banii <br/>moldovenilor?
            </div>
            <p style={{color:'var(--paper-3)', fontSize:'14px', maxWidth:'380px', lineHeight:1.6}}>
              Platformă independentă de transparență bugetară. Date oficiale MTender, Ministerul Finanțelor, Banca Mondială BOOST.
            </p>
            <div style={{display:'flex', gap:'8px', marginTop:'20px'}}>
              <span className="tag" style={{borderColor:'var(--paper-3)', color:'var(--paper)', background:'transparent'}}>EUPL-1.2</span>
              <span className="tag" style={{borderColor:'var(--paper-3)', color:'var(--paper)', background:'transparent'}}>Date CC0</span>
              <span className="tag" style={{borderColor:'var(--paper-3)', color:'var(--paper)', background:'transparent'}}>OCDS 1.1</span>
            </div>
          </div>
          {[
            { t: 'Explorare', l: ['Buget de stat','Achiziții','Sectoare','Autorități'] },
            { t: 'Date', l: ['API','CSV / JSON','OCDS','Metodologie'] },
            { t: 'Proiect', l: ['Despre','Cohesion Lab','GitHub','Contact'] },
          ].map(col => (
            <div key={col.t}>
              <div className="eyebrow" style={{color:'var(--paper-3)', marginBottom:'12px'}}>{col.t}</div>
              {col.l.map(l => <div key={l} style={{marginBottom:'8px', fontSize:'14px', color:'var(--paper)'}}>{l}</div>)}
            </div>
          ))}
        </div>
        <hr style={{border:0, borderTop:'1px solid #333', margin:'24px 0'}} />
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', fontSize:'12px', color:'var(--paper-3)'}}>
          <div className="mono">© 2025 · COHESION LAB · BUGET.COHESIONLAB.ORG</div>
          <div className="mono">Actualizat: 18.04.2026 · 14:22 EEST</div>
        </div>
      </div>
    </footer>
  );
}

Object.assign(window, { CountUp, Eyebrow, Nav, Footer });
