// Shared data for Buget Deschis Moldova redesign
window.BUDGET_DATA_2024 = {
  year: 2024,
  totalApproved: 100000,
  totalActual: 94200,
  executionRate: 93.1,
  sectors: [
    { id: 'social', name: 'Protecție Socială', nameEn: 'Social Protection', code: '10', approved: 28500, actual: 27200, color: 'var(--d-social)', story: 'Pensii, alocații, asistență' },
    { id: 'education', name: 'Educație', nameEn: 'Education', code: '09', approved: 18200, actual: 17100, color: 'var(--d-education)', story: 'Școli, universități, burse' },
    { id: 'health', name: 'Sănătate', nameEn: 'Healthcare', code: '07', approved: 15800, actual: 14900, color: 'var(--d-health)', story: 'Spitale, CNAM, medicamente' },
    { id: 'general', name: 'Servicii Generale', nameEn: 'General Services', code: '01', approved: 9400, actual: 8800, color: 'var(--d-general)', story: 'Administrație, Parlament' },
    { id: 'security', name: 'Ordine Publică', nameEn: 'Public Order', code: '03', approved: 8600, actual: 8100, color: 'var(--d-security)', story: 'Poliție, pompieri, justiție' },
    { id: 'economy', name: 'Afaceri Economice', nameEn: 'Economic Affairs', code: '04', approved: 7200, actual: 6900, color: 'var(--d-economy)', story: 'Drumuri, agricultură, IT' },
    { id: 'defense', name: 'Apărare', nameEn: 'Defense', code: '02', approved: 4100, actual: 3900, color: 'var(--d-defense)', story: 'Armata Națională' },
    { id: 'environment', name: 'Mediu', nameEn: 'Environment', code: '05', approved: 2800, actual: 2600, color: 'var(--d-environment)', story: 'Ape, păduri, deșeuri' },
    { id: 'debt', name: 'Datorie Publică', nameEn: 'Public Debt', code: '12', approved: 2000, actual: 1600, color: 'var(--d-debt)', story: 'Dobânzi, amortizare' },
    { id: 'housing', name: 'Locuințe', nameEn: 'Housing', code: '06', approved: 1900, actual: 1700, color: 'var(--d-housing)', story: 'Locuințe sociale, utilități' },
    { id: 'culture', name: 'Cultură & Sport', nameEn: 'Culture', code: '08', approved: 1500, actual: 1400, color: 'var(--d-culture)', story: 'Muzee, teatre, sport' },
  ]
};

window.BUDGET_TREND = [
  { year: 2019, approved: 62.3, actual: 59.8, euFunds: 2.1 },
  { year: 2020, approved: 68.1, actual: 65.2, euFunds: 2.8 },
  { year: 2021, approved: 75.4, actual: 72.4, euFunds: 3.5 },
  { year: 2022, approved: 84.2, actual: 79.8, euFunds: 5.2 },
  { year: 2023, approved: 93.1, actual: 88.5, euFunds: 7.8 },
  { year: 2024, approved: 100.0, actual: 94.2, euFunds: 9.4 },
];

window.TENDERS = [
  { id: '2024-03847', title: 'Reabilitare drum R1 Chișinău–Ungheni, tronson 12km', authority: 'Administrația de Stat a Drumurilor', value: 342500000, method: 'open', status: 'awarded', date: '2024-11-12', bids: 4, winner: 'Drumuri-Bălți SA', sector: 'Transport', flag: null },
  { id: '2024-03901', title: 'Medicamente oncologice, lot anual 2025', authority: 'CNAM', value: 186400000, method: 'open', status: 'active', date: '2024-12-01', bids: 0, winner: null, sector: 'Sănătate', flag: null },
  { id: '2024-03755', title: 'Servicii de catering școli primare raionul Orhei', authority: 'Consiliul Raional Orhei', value: 24800000, method: 'limited', status: 'awarded', date: '2024-10-28', bids: 2, winner: 'Gastro-Prim SRL', sector: 'Educație', flag: 'low-competition' },
  { id: '2024-03820', title: 'Modernizare sistem iluminat stradal Bălți', authority: 'Primăria Bălți', value: 58300000, method: 'open', status: 'awarded', date: '2024-11-05', bids: 6, winner: 'Iluminat-Tech SRL', sector: 'Infrastructură', flag: null },
  { id: '2024-03712', title: 'Echipamente medicale Spitalul Republican', authority: 'MS Moldova', value: 94100000, method: 'direct', status: 'cancelled', date: '2024-10-15', bids: 1, winner: null, sector: 'Sănătate', flag: 'single-bidder' },
  { id: '2024-03965', title: 'Construcție grădiniță 280 locuri Strășeni', authority: 'Consiliul Raional Strășeni', value: 41200000, method: 'open', status: 'active', date: '2024-12-08', bids: 3, winner: null, sector: 'Educație', flag: null },
  { id: '2024-03688', title: 'Software management achiziții publice', authority: 'Agenția de Guvernare Electronică', value: 12600000, method: 'open', status: 'awarded', date: '2024-09-22', bids: 5, winner: 'StisoftDev SRL', sector: 'IT', flag: null },
  { id: '2024-03872', title: 'Reparație capitală sediu judecătorie Cahul', authority: 'Ministerul Justiției', value: 18900000, method: 'direct', status: 'awarded', date: '2024-11-18', bids: 1, winner: 'Constr-Sud SRL', sector: 'Infrastructură', flag: 'single-bidder' },
  { id: '2024-04001', title: 'Manuale școlare clasele V–IX, anul 2025', authority: 'Ministerul Educației', value: 67500000, method: 'open', status: 'active', date: '2024-12-10', bids: 0, winner: null, sector: 'Educație', flag: null },
  { id: '2024-03798', title: 'Combustibil transport public urban', authority: 'Primăria Chișinău', value: 128300000, method: 'open', status: 'awarded', date: '2024-10-30', bids: 3, winner: 'Petrol-MD SA', sector: 'Transport', flag: null },
];

window.fmt = {
  mdl: (v) => v.toLocaleString('ro-MD'),
  short: (v) => {
    if (v >= 1e9) return (v/1e9).toFixed(1) + ' mld';
    if (v >= 1e6) return (v/1e6).toFixed(1) + ' mil';
    if (v >= 1e3) return (v/1e3).toFixed(1) + 'K';
    return v.toString();
  },
  pct: (v) => v.toFixed(1) + '%',
};
